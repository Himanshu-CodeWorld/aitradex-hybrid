import 'package:aitradex/core/theme/app_theme.dart';
import 'package:aitradex/core/theme/theme_controller.dart';
import 'package:aitradex/firebase_options.dart';
import 'package:aitradex/screens/account/app_lock_gate.dart';
import 'package:aitradex/screens/auth/signin/signin_screen.dart';
import 'package:aitradex/screens/bottomNavigation/bottom_nav.dart';
import 'package:aitradex/screens/splash/splash_screen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // ============================================================
  // FIREBASE INITIALIZATION
  // ============================================================

  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );

    debugPrint('========================================');
    debugPrint('🔥 Firebase initialized successfully');
    debugPrint('========================================');
  } catch (error, stackTrace) {
    debugPrint('========================================');
    debugPrint('❌ Firebase initialization failed');
    debugPrint('Error: $error');
    debugPrint('StackTrace: $stackTrace');
    debugPrint('========================================');

    // Do not continue with an app that requires Firebase
    // authentication if Firebase initialization failed.
    return;
  }

  // ============================================================
  // GLOBAL THEME CONTROLLER
  // ============================================================

  if (!Get.isRegistered<ThemeController>()) {
    Get.put<ThemeController>(
      ThemeController(),
      permanent: true,
    );
  }

  // ============================================================
  // RUN APP
  // ============================================================

  runApp(
    const MyApp(),
  );
}

// ============================================================================
// MY APP
// ============================================================================

class MyApp extends StatelessWidget {
  const MyApp({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final ThemeController themeController =
    Get.find<ThemeController>();

    return GetMaterialApp(
      title: 'AiTradeX',

      debugShowCheckedModeBanner: false,

      // ==========================================================
      // LIGHT THEME
      // ==========================================================

      theme: AppTheme.lightTheme(
        themeController.primaryColor.value,
      ),

      // ==========================================================
      // DARK THEME
      // ==========================================================

      darkTheme: AppTheme.darkTheme(
        themeController.primaryColor.value,
      ),

      // ==========================================================
      // THEME MODE
      // ==========================================================

      themeMode: themeController.isDarkMode.value
          ? ThemeMode.dark
          : ThemeMode.light,

      // ==========================================================
      // PAGE TRANSITION
      // ==========================================================

      defaultTransition: Transition.fadeIn,

      transitionDuration: const Duration(
        milliseconds: 300,
      ),

      // ==========================================================
      // INITIAL SCREEN
      // ==========================================================

      home: const SplashScreen(),

      // ==========================================================
      // NAMED ROUTES
      // ==========================================================

      getPages: [
        // --------------------------------------------------------
        // LOGIN
        // --------------------------------------------------------

        GetPage(
          name: '/login',
          page: () => const SignInScreen(),
          transition: Transition.fadeIn,
          transitionDuration: const Duration(
            milliseconds: 300,
          ),
        ),

        // --------------------------------------------------------
        // AUTHENTICATED APP
        // --------------------------------------------------------

        GetPage(
          name: '/bottom-nav',
          page: () => const AppLockGate(
            child: BottomNav(),
          ),
          transition: Transition.fadeIn,
          transitionDuration: const Duration(
            milliseconds: 300,
          ),
        ),
      ],
    );
  }
}