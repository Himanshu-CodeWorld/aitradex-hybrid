import 'dart:async';

import 'package:get/get.dart';

import '../models/market_data_model.dart';
import '../services/upstox_service.dart';

/// GetX controller for live AiTradeX market data.
///
/// Data flow:
/// Flutter -> AiTradeX backend -> Upstox V3 -> Flutter
///
/// Upstox credentials/tokens are never stored in this controller.
class MarketDataController extends GetxController {
  // ==========================================================
  // STATE
  // ==========================================================

  final RxBool isLoading = false.obs;
  final RxBool isRefreshing = false.obs;
  final RxBool hasError = false.obs;
  final RxString errorMessage = ''.obs;

  final RxList<MarketDataModel> marketData =
      <MarketDataModel>[].obs;

  Timer? _refreshTimer;

  bool _requestInProgress = false;

  // ==========================================================
  // DEFAULT INSTRUMENTS
  // ==========================================================

  List<String> get instrumentKeys =>
      List<String>.unmodifiable(
        UpstoxService.defaultInstrumentKeys,
      );

  // ==========================================================
  // LIFECYCLE
  // ==========================================================

  @override
  void onInit() {
    super.onInit();

    fetchMarketData();
    _startAutoRefresh();
  }

  @override
  void onClose() {
    _refreshTimer?.cancel();
    _refreshTimer = null;

    super.onClose();
  }

  // ==========================================================
  // FETCH MARKET DATA
  // ==========================================================

  Future<void> fetchMarketData({
    bool refresh = false,
  }) async {
    // Prevent overlapping requests from pull-to-refresh,
    // manual refresh and the 30-second timer.
    if (_requestInProgress) {
      return;
    }

    _requestInProgress = true;

    if (refresh) {
      isRefreshing.value = true;
    } else {
      isLoading.value = true;
    }

    hasError.value = false;
    errorMessage.value = '';

    try {
      final response = await UpstoxService.getMarketData(
        instrumentKeys: instrumentKeys,
      );

      final success = response['success'];

      if (success != true) {
        throw Exception(
          _readResponseMessage(response) ??
              'Unable to load market data.',
        );
      }

      final parsedData = _parseResponse(response);

      if (parsedData.isEmpty) {
        throw Exception(
          'No live market data was returned. '
              'Please connect Upstox and try again.',
        );
      }

      marketData.assignAll(parsedData);
    } catch (error) {
      hasError.value = true;
      errorMessage.value = _cleanErrorMessage(error);
    } finally {
      _requestInProgress = false;

      isLoading.value = false;
      isRefreshing.value = false;
    }
  }

  // ==========================================================
  // PARSE BACKEND RESPONSE
  // ==========================================================

  List<MarketDataModel> _parseResponse(
      Map<String, dynamic> response,
      ) {
    dynamic data = response['data'];

    // Handle nested response:
    // { data: { data: {...} } }
    if (data is Map) {
      final map = Map<String, dynamic>.from(data);

      data = map['data'] ??
          map['market_data'] ??
          map['marketData'] ??
          map['quotes'] ??
          data;
    }

    // Handle:
    // { data: [ {...}, {...} ] }
    if (data is List) {
      return data
          .whereType<Map>()
          .map(
            (item) => MarketDataModel.fromJson(
          Map<String, dynamic>.from(item),
        ),
      )
          .toList();
    }

    // Handle:
    // {
    //   data: {
    //     "NSE_EQ|...": {
    //       "last_price": 123.45
    //     }
    //   }
    // }
    if (data is Map) {
      final map = Map<String, dynamic>.from(data);

      final result = <MarketDataModel>[];

      for (final entry in map.entries) {
        if (entry.value is! Map) {
          continue;
        }

        final quote =
        Map<String, dynamic>.from(entry.value as Map);

        quote.putIfAbsent(
          'instrument_key',
              () => entry.key,
        );

        try {
          result.add(
            MarketDataModel.fromJson(quote),
          );
        } catch (_) {
          // Ignore malformed individual quotes rather than
          // failing the complete market response.
        }
      }

      return result;
    }

    return <MarketDataModel>[];
  }

  // ==========================================================
  // AUTO REFRESH
  // ==========================================================

  void _startAutoRefresh() {
    _refreshTimer?.cancel();

    _refreshTimer = Timer.periodic(
      const Duration(seconds: 30),
          (_) {
        if (!_requestInProgress &&
            !isLoading.value &&
            !isRefreshing.value) {
          fetchMarketData(refresh: true);
        }
      },
    );
  }

  // ==========================================================
  // MANUAL REFRESH
  // ==========================================================

  Future<void> refreshMarketData() {
    return fetchMarketData(refresh: true);
  }

  // ==========================================================
  // ERROR HANDLING
  // ==========================================================

  String? _readResponseMessage(
      Map<String, dynamic> response,
      ) {
    for (final key in const [
      'message',
      'error',
      'error_description',
      'detail',
    ]) {
      final value = response[key];

      if (value != null &&
          value.toString().trim().isNotEmpty) {
        return value.toString().trim();
      }
    }

    return null;
  }

  String _cleanErrorMessage(Object error) {
    var message = error.toString().trim();

    if (message.startsWith('Exception: ')) {
      message =
          message.substring('Exception: '.length);
    }

    if (message.isEmpty) {
      return 'Unable to load market data. Please try again.';
    }

    return message;
  }

  // ==========================================================
  // FIND INSTRUMENT
  // ==========================================================

  MarketDataModel? findInstrument(
      String instrumentKey,
      ) {
    final key = instrumentKey.trim();

    if (key.isEmpty) {
      return null;
    }

    for (final item in marketData) {
      if (item.instrumentKey == key) {
        return item;
      }
    }

    return null;
  }
}
