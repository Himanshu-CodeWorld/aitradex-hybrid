
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

const Color _rewardsGold = Color(0xFFFFB547);

/// Opens when the user taps "Get free stock" from Account.
class InviteFriendsScreen extends StatelessWidget {
  const InviteFriendsScreen({super.key});

  static const List<_InviteStepData> _steps = [
    _InviteStepData(
      number: '01',
      icon: Icons.link_rounded,
      title: 'Invite your friends',
      description:
      'Send your friends your personal invite link and invite them to AiTradeX.',
    ),
    _InviteStepData(
      number: '02',
      icon: Icons.card_giftcard_rounded,
      title: 'They get free stock',
      description:
      'Your friends get \$5 of free stock when they join.',
      linkText: 'Terms apply.',
    ),
    _InviteStepData(
      number: '03',
      icon: Icons.auto_awesome_rounded,
      title: 'You get rewarded',
      description:
      'Get rewarded when your friends join AiTradeX.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Expanded(
              child: CustomScrollView(
                physics: const BouncingScrollPhysics(),
                slivers: [
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(
                      20,
                      18,
                      20,
                      130,
                    ),
                    sliver: SliverList(
                      delegate: SliverChildListDelegate([
                        _TopBar(
                          title: 'Invite Friends',
                          onBack: () =>
                              Navigator.of(context).pop(),
                        ),
                        const SizedBox(height: 18),
                        _InviteHero(
                          primary: scheme.primary,
                          scheme: scheme,
                        ),
                        const SizedBox(height: 24),
                        _SectionTitle(
                          title: 'How it works',
                          subtitle:
                          'Invite friends and earn rewards together.',
                        ),
                        const SizedBox(height: 12),
                        ..._steps.map(
                              (step) => Padding(
                            padding:
                            const EdgeInsets.only(bottom: 10),
                            child: _InviteStep(
                              data: step,
                              primary: scheme.primary,
                              scheme: scheme,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        _RewardHighlight(
                          primary: scheme.primary,
                          scheme: scheme,
                        ),
                      ]),
                    ),
                  ),
                ],
              ),
            ),
            _BottomActions(
              primaryText: 'Share My Invite Link',
              primaryIcon: Icons.ios_share_rounded,
              onPrimary: () => _shareInvite(context),
              secondaryText: 'My Rewards',
              secondaryIcon: Icons.card_giftcard_rounded,
              onSecondary: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => const MyRewardsScreen(),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  void _shareInvite(BuildContext context) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.fromLTRB(18, 0, 18, 18),
          backgroundColor:
          Theme.of(context).colorScheme.inverseSurface,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          content: Text(
            'Invite link ready to share.',
            style: GoogleFonts.poppins(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: Theme.of(context)
                  .colorScheme
                  .onInverseSurface,
            ),
          ),
        ),
      );
  }
}

class MyRewardsScreen extends StatelessWidget {
  const MyRewardsScreen({super.key});

  static const List<_RewardPerson> _people = [
    _RewardPerson('Augustina Midgett', '\$5', 'AM'),
    _RewardPerson('Chieko Chute', '\$10', 'CC'),
    _RewardPerson('Thad Eddings', '\$10', 'TE'),
    _RewardPerson('Maryland Winkles', '\$5', 'MW'),
    _RewardPerson('Merrill Kervin', '\$5', 'MK'),
    _RewardPerson('Florencio Dorrance', '\$10', 'FD'),
  ];

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Expanded(
              child: CustomScrollView(
                physics: const BouncingScrollPhysics(),
                slivers: [
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(
                      20,
                      18,
                      20,
                      130,
                    ),
                    sliver: SliverList(
                      delegate: SliverChildListDelegate([
                        _TopBar(
                          title: 'My Rewards',
                          showSearch: true,
                          onBack: () =>
                              Navigator.of(context).pop(),
                          onSearch: () =>
                              _showSearch(context),
                        ),
                        const SizedBox(height: 24),
                        _RewardsSummary(
                          primary: scheme.primary,
                          scheme: scheme,
                        ),
                        const SizedBox(height: 24),
                        _SectionTitle(
                          title: 'Your friends',
                          subtitle:
                          'Friends who joined through your invite.',
                        ),
                        const SizedBox(height: 12),
                        _RewardsList(
                          people: _people,
                          primary: scheme.primary,
                          scheme: scheme,
                        ),
                      ]),
                    ),
                  ),
                ],
              ),
            ),
            _BottomActions(
              primaryText: 'Share My Invite Link',
              primaryIcon: Icons.ios_share_rounded,
              onPrimary: () => _share(context),
            ),
          ],
        ),
      ),
    );
  }

  void _share(BuildContext context) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: const Text('Invite link ready to share.'),
          behavior: SnackBarBehavior.floating,
          backgroundColor:
          Theme.of(context).colorScheme.inverseSurface,
        ),
      );
  }

  void _showSearch(BuildContext context) {
    showSearch(
      context: context,
      delegate: _RewardsSearchDelegate(),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({
    required this.title,
    required this.onBack,
    this.showSearch = false,
    this.onSearch,
  });

  final String title;
  final VoidCallback onBack;
  final bool showSearch;
  final VoidCallback? onSearch;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;

    return Row(
      children: [
        Material(
          color: scheme.surfaceContainerHighest.withValues(
            alpha:
            Theme.of(context).brightness == Brightness.dark
                ? 0.55
                : 0.70,
          ),
          borderRadius: BorderRadius.circular(14),
          child: InkWell(
            onTap: onBack,
            borderRadius: BorderRadius.circular(14),
            child: const SizedBox(
              width: 42,
              height: 42,
              child: Icon(
                Icons.arrow_back_rounded,
                size: 22,
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            title,
            style: GoogleFonts.poppins(
              fontSize: 22,
              fontWeight: FontWeight.w700,
              letterSpacing: -0.4,
              color: scheme.onSurface,
            ),
          ),
        ),
        if (showSearch)
          Material(
            color: scheme.surfaceContainerHighest.withValues(
              alpha:
              Theme.of(context).brightness == Brightness.dark
                  ? 0.55
                  : 0.70,
            ),
            borderRadius: BorderRadius.circular(14),
            child: InkWell(
              onTap: onSearch,
              borderRadius: BorderRadius.circular(14),
              child: const SizedBox(
                width: 42,
                height: 42,
                child: Icon(
                  Icons.search_rounded,
                  size: 22,
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class _InviteHero extends StatelessWidget {
  const _InviteHero({
    required this.primary,
    required this.scheme,
  });

  final Color primary;
  final ColorScheme scheme;

  @override
  Widget build(BuildContext context) {
    final bool isDark =
        Theme.of(context).brightness == Brightness.dark;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 22),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(
          color: primary.withValues(
            alpha: isDark ? 0.20 : 0.10,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: primary.withValues(
              alpha: isDark ? 0.10 : 0.06,
            ),
            blurRadius: 30,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Column(
        children: [
          const SizedBox(
            height: 205,
            child: _InviteIllustration(),
          ),
          const SizedBox(height: 6),
          Text(
            'Invite friends.',
            textAlign: TextAlign.center,
            style: GoogleFonts.poppins(
              fontSize: 29,
              height: 1.15,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.8,
              color: scheme.onSurface,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            'Get free stock!',
            textAlign: TextAlign.center,
            style: GoogleFonts.poppins(
              fontSize: 29,
              height: 1.15,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.8,
              color: primary,
            ),
          ),
          const SizedBox(height: 14),
          Text(
            'Share AiTradeX with your friends and earn rewards when they join.',
            textAlign: TextAlign.center,
            style: GoogleFonts.poppins(
              fontSize: 12.5,
              height: 1.55,
              fontWeight: FontWeight.w500,
              color: scheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({
    required this.title,
    required this.subtitle,
  });

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 3),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.poppins(
              fontSize: 17,
              fontWeight: FontWeight.w700,
              color: scheme.onSurface,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            subtitle,
            style: GoogleFonts.poppins(
              fontSize: 11.5,
              fontWeight: FontWeight.w500,
              color: scheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}

class _InviteStepData {
  const _InviteStepData({
    required this.number,
    required this.icon,
    required this.title,
    required this.description,
    this.linkText,
  });

  final String number;
  final IconData icon;
  final String title;
  final String description;
  final String? linkText;
}

class _InviteStep extends StatelessWidget {
  const _InviteStep({
    required this.data,
    required this.primary,
    required this.scheme,
  });

  final _InviteStepData data;
  final Color primary;
  final ColorScheme scheme;

  @override
  Widget build(BuildContext context) {
    final bool isDark =
        Theme.of(context).brightness == Brightness.dark;

    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(21),
        border: Border.all(
          color: scheme.outline.withValues(
            alpha: isDark ? 0.25 : 0.13,
          ),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 47,
            height: 47,
            decoration: BoxDecoration(
              color: primary.withValues(
                alpha: isDark ? 0.13 : 0.07,
              ),
              borderRadius: BorderRadius.circular(15),
            ),
            child: Icon(
              data.icon,
              size: 21,
              color: primary,
            ),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        data.title,
                        style: GoogleFonts.poppins(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: scheme.onSurface,
                        ),
                      ),
                    ),
                    Text(
                      data.number,
                      style: GoogleFonts.poppins(
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        color: primary.withValues(
                          alpha: 0.65,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 5),
                RichText(
                  text: TextSpan(
                    style: GoogleFonts.poppins(
                      fontSize: 11.5,
                      height: 1.45,
                      fontWeight: FontWeight.w500,
                      color: scheme.onSurfaceVariant,
                    ),
                    children: [
                      TextSpan(text: data.description),
                      if (data.linkText != null)
                        TextSpan(
                          text: ' ${data.linkText}',
                          style: TextStyle(
                            color: primary,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _RewardHighlight extends StatelessWidget {
  const _RewardHighlight({
    required this.primary,
    required this.scheme,
  });

  final Color primary;
  final ColorScheme scheme;

  @override
  Widget build(BuildContext context) {
    final bool isDark =
        Theme.of(context).brightness == Brightness.dark;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            primary.withValues(alpha: isDark ? 0.16 : 0.09),
            primary.withValues(alpha: isDark ? 0.07 : 0.035),
          ],
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: primary.withValues(
            alpha: isDark ? 0.22 : 0.12,
          ),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: primary,
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.auto_awesome_rounded,
              color: scheme.onPrimary,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'Keep inviting friends to unlock more rewards.',
              style: GoogleFonts.poppins(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: scheme.onSurface,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _InviteIllustration extends StatelessWidget {
  const _InviteIllustration();

  @override
  Widget build(BuildContext context) {
    final Color primary =
        Theme.of(context).colorScheme.primary;

    return Stack(
      alignment: Alignment.bottomCenter,
      children: [
        Positioned(
          left: 20,
          top: 52,
          child: _Firework(
            color: _rewardsGold,
            size: 50,
          ),
        ),
        Positioned(
          left: 62,
          top: 8,
          child: _Firework(
            color: const Color(0xFF7B68FF),
            size: 40,
          ),
        ),
        Positioned(
          right: 62,
          top: 4,
          child: _Firework(
            color: primary,
            size: 54,
          ),
        ),
        Positioned(
          right: 17,
          top: 56,
          child: _Firework(
            color: const Color(0xFFFF7F86),
            size: 40,
          ),
        ),
        Positioned(
          right: 46,
          top: 42,
          child: _Firework(
            color: const Color(0xFFFFB84A),
            size: 23,
          ),
        ),
        Positioned(
          left: 58,
          bottom: 0,
          child: _PersonIllustration(
            shirtColor: primary,
            skirt: true,
            scale: 0.95,
          ),
        ),
        Positioned(
          left: 128,
          bottom: 0,
          child: _PersonIllustration(
            shirtColor: primary,
            scale: 1.03,
          ),
        ),
        Positioned(
          right: 48,
          bottom: 0,
          child: _PersonIllustration(
            shirtColor: primary,
            scale: 0.95,
          ),
        ),
        Positioned(
          left: 52,
          right: 52,
          bottom: 0,
          child: Container(
            height: 1,
            color: Theme.of(context)
                .colorScheme
                .outline
                .withValues(alpha: 0.55),
          ),
        ),
      ],
    );
  }
}

class _Firework extends StatelessWidget {
  const _Firework({
    required this.color,
    required this.size,
  });

  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _FireworkPainter(color),
      ),
    );
  }
}

class _FireworkPainter extends CustomPainter {
  _FireworkPainter(this.color);

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..color = color
      ..strokeWidth = 1.25
      ..style = PaintingStyle.stroke;

    final Offset center = Offset(
      size.width / 2,
      size.height / 2,
    );
    final double radius = size.width * 0.43;

    for (int i = 0; i < 16; i++) {
      final double angle = i * 3.14159265359 / 8;
      final Offset start = Offset(
        center.dx + radius * 0.18 * _cos(angle),
        center.dy + radius * 0.18 * _sin(angle),
      );
      final Offset end = Offset(
        center.dx + radius * _cos(angle),
        center.dy + radius * _sin(angle),
      );

      canvas.drawLine(start, end, paint);
    }
  }

  double _cos(double value) => _Trig.cos(value);

  double _sin(double value) => _Trig.sin(value);

  @override
  bool shouldRepaint(
      covariant _FireworkPainter oldDelegate,
      ) {
    return oldDelegate.color != color;
  }
}

class _Trig {
  static double sin(double x) {
    double term = x;
    double sum = x;

    for (int n = 1; n <= 6; n++) {
      term *=
          -x * x / ((2 * n) * (2 * n + 1));
      sum += term;
    }

    return sum;
  }

  static double cos(double x) {
    return sin(x + 1.57079632679);
  }
}

class _PersonIllustration extends StatelessWidget {
  const _PersonIllustration({
    required this.shirtColor,
    this.skirt = false,
    this.scale = 1,
  });

  final Color shirtColor;
  final bool skirt;
  final double scale;

  @override
  Widget build(BuildContext context) {
    final Color darkFigure = Theme.of(context)
        .colorScheme
        .onSurface
        .withValues(alpha: 0.92);

    return SizedBox(
      width: 65 * scale,
      height: 160 * scale,
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.topCenter,
        children: [
          Positioned(
            top: 0,
            child: Container(
              width: 18 * scale,
              height: 18 * scale,
              decoration: BoxDecoration(
                color: darkFigure,
                shape: BoxShape.circle,
              ),
            ),
          ),
          Positioned(
            top: 20 * scale,
            child: Container(
              width: 40 * scale,
              height: 55 * scale,
              decoration: BoxDecoration(
                color: shirtColor,
                borderRadius:
                BorderRadius.circular(18 * scale),
              ),
            ),
          ),
          Positioned(
            top: 70 * scale,
            left: 18 * scale,
            child: Container(
              width: 11 * scale,
              height: 68 * scale,
              decoration: BoxDecoration(
                color: darkFigure,
                borderRadius:
                BorderRadius.circular(7 * scale),
              ),
            ),
          ),
          Positioned(
            top: 70 * scale,
            right: 18 * scale,
            child: Container(
              width: 11 * scale,
              height: 68 * scale,
              decoration: BoxDecoration(
                color: darkFigure,
                borderRadius:
                BorderRadius.circular(7 * scale),
              ),
            ),
          ),
          Positioned(
            top: 35 * scale,
            left: 0,
            child: Transform.rotate(
              angle: -.45,
              child: Container(
                width: 11 * scale,
                height: 58 * scale,
                decoration: BoxDecoration(
                  color: shirtColor,
                  borderRadius:
                  BorderRadius.circular(7 * scale),
                ),
              ),
            ),
          ),
          Positioned(
            top: 35 * scale,
            right: 0,
            child: Transform.rotate(
              angle: .45,
              child: Container(
                width: 11 * scale,
                height: 58 * scale,
                decoration: BoxDecoration(
                  color: shirtColor,
                  borderRadius:
                  BorderRadius.circular(7 * scale),
                ),
              ),
            ),
          ),
          if (skirt)
            Positioned(
              top: 67 * scale,
              child: Transform.rotate(
                angle: -.08,
                child: Container(
                  width: 47 * scale,
                  height: 18 * scale,
                  decoration: BoxDecoration(
                    color: darkFigure,
                    borderRadius:
                    BorderRadius.circular(7 * scale),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _RewardsSummary extends StatelessWidget {
  const _RewardsSummary({
    required this.primary,
    required this.scheme,
  });

  final Color primary;
  final ColorScheme scheme;

  @override
  Widget build(BuildContext context) {
    final bool isDark =
        Theme.of(context).brightness == Brightness.dark;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(
          color: primary.withValues(
            alpha: isDark ? 0.20 : 0.10,
          ),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: primary.withValues(
                    alpha: isDark ? 0.14 : 0.08,
                  ),
                  borderRadius:
                  BorderRadius.circular(16),
                ),
                child: Icon(
                  Icons.celebration_rounded,
                  color: primary,
                  size: 24,
                ),
              ),
              const SizedBox(width: 13),
              Expanded(
                child: Text(
                  'Your referral rewards',
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: scheme.onSurface,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: _StatCard(
                  value: '25',
                  label: 'Friends invited',
                  primary: primary,
                  scheme: scheme,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _StatCard(
                  value: '\$250',
                  label: 'Free stock unlocked',
                  primary: primary,
                  scheme: scheme,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            'Keep inviting friends to unlock more!',
            textAlign: TextAlign.center,
            style: GoogleFonts.poppins(
              fontSize: 11.5,
              fontWeight: FontWeight.w500,
              color: scheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({
    required this.value,
    required this.label,
    required this.primary,
    required this.scheme,
  });

  final String value;
  final String label;
  final Color primary;
  final ColorScheme scheme;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 13,
      ),
      decoration: BoxDecoration(
        color: primary.withValues(
          alpha: Theme.of(context).brightness ==
              Brightness.dark
              ? 0.10
              : 0.055,
        ),
        borderRadius: BorderRadius.circular(17),
      ),
      child: Column(
        children: [
          Text(
            value,
            style: GoogleFonts.poppins(
              fontSize: 21,
              fontWeight: FontWeight.w800,
              color: primary,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            label,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.poppins(
              fontSize: 9.5,
              height: 1.25,
              fontWeight: FontWeight.w600,
              color: scheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}

class _RewardsList extends StatelessWidget {
  const _RewardsList({
    required this.people,
    required this.primary,
    required this.scheme,
  });

  final List<_RewardPerson> people;
  final Color primary;
  final ColorScheme scheme;

  @override
  Widget build(BuildContext context) {
    final bool isDark =
        Theme.of(context).brightness == Brightness.dark;

    return Container(
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: scheme.outline.withValues(
            alpha: isDark ? 0.25 : 0.13,
          ),
        ),
      ),
      child: ListView.separated(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: people.length,
        separatorBuilder: (_, __) => Divider(
          height: 1,
          thickness: 0.7,
          indent: 80,
          endIndent: 16,
          color: scheme.outline.withValues(
            alpha: isDark ? 0.20 : 0.10,
          ),
        ),
        itemBuilder: (context, index) {
          return _RewardRow(
            person: people[index],
            primary: primary,
            scheme: scheme,
          );
        },
      ),
    );
  }
}

class _RewardPerson {
  const _RewardPerson(
      this.name,
      this.amount,
      this.initials,
      );

  final String name;
  final String amount;
  final String initials;
}

class _RewardRow extends StatelessWidget {
  const _RewardRow({
    required this.person,
    required this.primary,
    required this.scheme,
  });

  final _RewardPerson person;
  final Color primary;
  final ColorScheme scheme;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () {},
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: 15,
            vertical: 12,
          ),
          child: Row(
            children: [
              _Avatar(
                initials: person.initials,
                primary: primary,
              ),
              const SizedBox(width: 13),
              Expanded(
                child: Column(
                  crossAxisAlignment:
                  CrossAxisAlignment.start,
                  children: [
                    Text(
                      person.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.poppins(
                        fontSize: 13.5,
                        fontWeight: FontWeight.w700,
                        color: scheme.onSurface,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      'Referral reward',
                      style: GoogleFonts.poppins(
                        fontSize: 10,
                        fontWeight: FontWeight.w500,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: primary.withValues(
                    alpha: Theme.of(context)
                        .brightness ==
                        Brightness.dark
                        ? 0.12
                        : 0.07,
                  ),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  person.amount,
                  style: GoogleFonts.poppins(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: primary,
                  ),
                ),
              ),
              const SizedBox(width: 7),
              Icon(
                Icons.chevron_right_rounded,
                size: 21,
                color: scheme.onSurfaceVariant
                    .withValues(alpha: 0.70),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Avatar extends StatelessWidget {
  const _Avatar({
    required this.initials,
    required this.primary,
  });

  final String initials;
  final Color primary;

  @override
  Widget build(BuildContext context) {
    final Color secondColor = Color(
      (initials.hashCode & 0x00FFFFFF) | 0xFF000000,
    );

    return Container(
      width: 52,
      height: 52,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            primary.withValues(alpha: 0.75),
            secondColor,
          ],
        ),
      ),
      alignment: Alignment.center,
      child: Text(
        initials,
        style: GoogleFonts.poppins(
          fontSize: 13,
          fontWeight: FontWeight.w800,
          color: Colors.white,
        ),
      ),
    );
  }
}

class _BottomActions extends StatelessWidget {
  const _BottomActions({
    required this.primaryText,
    required this.primaryIcon,
    required this.onPrimary,
    this.secondaryText,
    this.secondaryIcon,
    this.onSecondary,
  });

  final String primaryText;
  final IconData primaryIcon;
  final VoidCallback onPrimary;
  final String? secondaryText;
  final IconData? secondaryIcon;
  final VoidCallback? onSecondary;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final bool isDark =
        theme.brightness == Brightness.dark;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(
        20,
        12,
        20,
        14 + MediaQuery.of(context).padding.bottom,
      ),
      decoration: BoxDecoration(
        color: scheme.surface,
        border: Border(
          top: BorderSide(
            color: scheme.outline.withValues(
              alpha: isDark ? 0.28 : 0.13,
            ),
            width: 0.8,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(
              alpha: isDark ? 0.20 : 0.06,
            ),
            blurRadius: 20,
            offset: const Offset(0, -8),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: double.infinity,
            height: 56,
            child: ElevatedButton.icon(
              onPressed: onPrimary,
              icon: Icon(
                primaryIcon,
                size: 19,
              ),
              label: Text(
                primaryText,
                style: GoogleFonts.poppins(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: scheme.primary,
                foregroundColor: scheme.onPrimary,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(19),
                ),
              ),
            ),
          ),
          if (secondaryText != null) ...[
            const SizedBox(height: 9),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: TextButton.icon(
                onPressed: onSecondary,
                icon: Icon(
                  secondaryIcon,
                  size: 19,
                  color: scheme.primary,
                ),
                label: Text(
                  secondaryText!,
                  style: GoogleFonts.poppins(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: scheme.primary,
                  ),
                ),
                style: TextButton.styleFrom(
                  backgroundColor:
                  scheme.primary.withValues(
                    alpha: isDark ? 0.11 : 0.065,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(18),
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _RewardsSearchDelegate
    extends SearchDelegate<String> {
  @override
  List<Widget>? buildActions(
      BuildContext context,
      ) {
    if (query.isEmpty) {
      return null;
    }

    return [
      IconButton(
        onPressed: () => query = '',
        icon: const Icon(Icons.clear_rounded),
      ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      onPressed: () => close(context, ''),
      icon: const Icon(Icons.arrow_back_rounded),
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    final ColorScheme scheme =
        Theme.of(context).colorScheme;

    return Center(
      child: Text(
        query.isEmpty
            ? 'Search rewards'
            : 'No matching rewards',
        style: GoogleFonts.poppins(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: scheme.onSurface,
        ),
      ),
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return buildResults(context);
  }
}