import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;

class GoogleAuthService {
  GoogleAuthService._();

  static final GoogleAuthService instance = GoogleAuthService._();

  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  final GoogleSignIn _googleSignIn = GoogleSignIn.instance;

  static const String _baseUrl =
      'https://aitradex-api.onrender.com/api';

  bool _initialized = false;

  Future<void> initialize() async {
    if (_initialized) {
      return;
    }

    await _googleSignIn.initialize();

    _initialized = true;
  }

  Future<User?> signInWithGoogle() async {
    try {
      await initialize();

      if (!_googleSignIn.supportsAuthenticate()) {
        throw Exception(
          'Google Sign-In is not supported on this platform.',
        );
      }

      final GoogleSignInAccount googleUser =
      await _googleSignIn.authenticate();

      final GoogleSignInAuthentication googleAuth =
          googleUser.authentication;

      final String? idToken = googleAuth.idToken;

      if (idToken == null || idToken.isEmpty) {
        throw Exception(
          'Google ID token was not returned.',
        );
      }

      final OAuthCredential credential =
      GoogleAuthProvider.credential(
        idToken: idToken,
      );

      final UserCredential userCredential =
      await _firebaseAuth.signInWithCredential(
        credential,
      );

      final User? firebaseUser = userCredential.user;

      if (firebaseUser == null) {
        throw Exception(
          'Firebase could not create the user session.',
        );
      }

      /*
       * Get the Firebase ID token.
       *
       * This token is sent to your Node.js backend.
       */
      final String? firebaseIdToken =
      await firebaseUser.getIdToken();

      if (firebaseIdToken == null ||
          firebaseIdToken.isEmpty) {
        throw Exception(
          'Firebase ID token could not be generated.',
        );
      }

      /*
       * Sync Firebase user with MongoDB.
       */
      await _syncUserWithBackend(
        firebaseIdToken: firebaseIdToken,
        firebaseUser: firebaseUser,
        isNewUser: userCredential.additionalUserInfo
            ?.isNewUser ??
            false,
      );

      return firebaseUser;
    } on GoogleSignInException catch (e) {
      debugPrint(
        'Google Sign-In error: ${e.code}',
      );

      throw Exception(
        _googleSignInErrorMessage(e),
      );
    } on FirebaseAuthException catch (e) {
      debugPrint(
        'Firebase Google Auth error: ${e.code}',
      );

      throw Exception(
        _firebaseErrorMessage(e),
      );
    } catch (e) {
      debugPrint(
        'Google authentication error: $e',
      );

      rethrow;
    }
  }

  Future<void> _syncUserWithBackend({
    required String firebaseIdToken,
    required User firebaseUser,
    required bool isNewUser,
  }) async {
    final Uri url = Uri.parse(
      '$_baseUrl/auth/google-sync',
    );

    final http.Response response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $firebaseIdToken',
      },
      body: jsonEncode({
        'isNewUser': isNewUser,
      }),
    );

    debugPrint(
      'MongoDB sync status: ${response.statusCode}',
    );

    if (response.statusCode < 200 ||
        response.statusCode >= 300) {
      debugPrint(
        'MongoDB sync response: ${response.body}',
      );

      throw Exception(
        'Your Firebase account was created, but your '
            'AiTradeX profile could not be synchronized.',
      );
    }
  }

  Future<void> signOut() async {
    try {
      await _googleSignIn.signOut();
    } catch (e) {
      debugPrint(
        'Google sign out error: $e',
      );
    }

    await _firebaseAuth.signOut();
  }

  String _googleSignInErrorMessage(
      GoogleSignInException error,
      ) {
    switch (error.code) {
      case GoogleSignInExceptionCode.canceled:
        return 'Google Sign-In was cancelled.';

      case GoogleSignInExceptionCode.clientConfigurationError:
        return 'Google Sign-In is not configured correctly.';

      case GoogleSignInExceptionCode.interrupted:
        return 'Google Sign-In was interrupted.';

      default:
        return 'Unable to sign in with Google.';
    }
  }

  String _firebaseErrorMessage(
      FirebaseAuthException error,
      ) {
    switch (error.code) {
      case 'account-exists-with-different-credential':
        return 'An account already exists with this email using another sign-in method.';

      case 'network-request-failed':
        return 'Please check your internet connection.';

      case 'operation-not-allowed':
        return 'Google Sign-In is not enabled in Firebase Authentication.';

      case 'invalid-credential':
        return 'Google authentication credentials are invalid.';

      default:
        return error.message ??
            'Firebase authentication failed.';
    }
  }
}