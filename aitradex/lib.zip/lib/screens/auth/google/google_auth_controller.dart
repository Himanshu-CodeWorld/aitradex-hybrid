import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;

class GoogleAuthController extends GetxController {
  GoogleAuthController();

  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  final RxBool isLoading = false.obs;

  static const String _baseUrl =
      'https://aitradex-api.onrender.com/api';

  /// Web OAuth client ID from google-services.json.
  ///
  /// This is the client_type: 3 OAuth client.
  static const String _serverClientId =
      '418085831140-vljcc8v8pnbe5ohgo5v2gvq4u0g55s0c.apps.googleusercontent.com';

  late final GoogleSignIn _googleSignIn;

  bool _googleInitialized = false;

  @override
  void onInit() {
    super.onInit();

    _googleSignIn = GoogleSignIn.instance;

    _initializeGoogleSignIn();
  }

  Future<void> _initializeGoogleSignIn() async {
    if (_googleInitialized) {
      return;
    }

    try {
      await _googleSignIn.initialize(
        serverClientId: _serverClientId,
      );

      _googleInitialized = true;

      debugPrint('========================================');
      debugPrint('✅ Google Sign-In initialized');
      debugPrint('========================================');
    } catch (error, stackTrace) {
      debugPrint('========================================');
      debugPrint('❌ Google Sign-In initialization failed');
      debugPrint('Error: $error');
      debugPrint('StackTrace: $stackTrace');
      debugPrint('========================================');
    }
  }

  Future<void> signInWithGoogle() async {
    if (isLoading.value) {
      return;
    }

    try {
      isLoading.value = true;

      debugPrint('========================================');
      debugPrint('🔵 Google Sign-In started');
      debugPrint('========================================');

      // Make absolutely sure initialization completed.
      if (!_googleInitialized) {
        await _initializeGoogleSignIn();
      }

      if (!_googleInitialized) {
        throw Exception(
          'Google Sign-In could not be initialized.',
        );
      }

      /*
       * STEP 1
       * Open Google's account selector.
       */
      debugPrint('🔵 Opening Google account selector...');

      final GoogleSignInAccount googleUser =
      await _googleSignIn.authenticate();

      debugPrint('========================================');
      debugPrint('✅ Google account selected');
      debugPrint('Name: ${googleUser.displayName}');
      debugPrint('Email: ${googleUser.email}');
      debugPrint('========================================');

      /*
       * STEP 2
       * Get Google authentication information.
       */
      final GoogleSignInAuthentication googleAuth =
          googleUser.authentication;

      final String? googleIdToken = googleAuth.idToken;

      debugPrint(
        'Google ID token available: ${googleIdToken != null}',
      );

      if (googleIdToken == null ||
          googleIdToken.isEmpty) {
        throw Exception(
          'Google ID token is missing. '
              'Check the Firebase OAuth configuration and SHA-1.',
        );
      }

      /*
       * STEP 3
       * Convert Google credential into Firebase credential.
       */
      final AuthCredential credential =
      GoogleAuthProvider.credential(
        idToken: googleIdToken,
      );

      debugPrint('🔵 Signing into Firebase...');

      /*
       * STEP 4
       * Firebase Authentication.
       */
      final UserCredential userCredential =
      await _firebaseAuth.signInWithCredential(
        credential,
      );

      final User? user = userCredential.user;

      if (user == null) {
        throw Exception(
          'Firebase did not return a user.',
        );
      }

      debugPrint('========================================');
      debugPrint('✅ Firebase Google Login Successful');
      debugPrint('UID: ${user.uid}');
      debugPrint('Name: ${user.displayName}');
      debugPrint('Email: ${user.email}');
      debugPrint('Photo: ${user.photoURL}');
      debugPrint(
        'Email verified: ${user.emailVerified}',
      );
      debugPrint('========================================');

      /*
       * STEP 5
       * Get Firebase ID token.
       */
      final String? firebaseIdToken =
      await user.getIdToken(true);

      if (firebaseIdToken == null ||
          firebaseIdToken.isEmpty) {
        throw Exception(
          'Firebase ID token is missing.',
        );
      }

      /*
       * STEP 6
       * Save/update user in AiTradeX MongoDB.
       */
      final bool backendSuccess =
      await _saveUserToBackend(
        user: user,
        firebaseIdToken: firebaseIdToken,
      );

      if (!backendSuccess) {
        throw Exception(
          'Unable to save Google user to AiTradeX server.',
        );
      }

      debugPrint('========================================');
      debugPrint('🎉 Google login completed');
      debugPrint('========================================');

      /*
       * STEP 7
       * Your actual registered route is /bottom-nav.
       *
       * Do NOT use /home.
       */
      Get.offAllNamed('/bottom-nav');
    } on GoogleSignInException catch (e) {
      debugPrint('========================================');
      debugPrint('❌ Google Sign-In Exception');
      debugPrint('Code: ${e.code}');
      debugPrint('Description: ${e.description}');
      debugPrint('Details: ${e.details}');
      debugPrint('========================================');

      /*
       * Important:
       *
       * google_sign_in can report "canceled" when there is
       * actually an Android OAuth configuration problem.
       */
      if (e.code ==
          GoogleSignInExceptionCode.canceled) {
        Get.snackbar(
          'Google Sign-In',
          'Google sign-in was cancelled or the Android '
              'Google OAuth configuration is incomplete.',
          snackPosition: SnackPosition.BOTTOM,
          duration: const Duration(seconds: 5),
        );
      } else {
        Get.snackbar(
          'Google Sign-In Failed',
          e.description ??
              'Unable to sign in with Google.',
          snackPosition: SnackPosition.BOTTOM,
          duration: const Duration(seconds: 5),
        );
      }
    } on FirebaseAuthException catch (e) {
      debugPrint('========================================');
      debugPrint('❌ Firebase Authentication Error');
      debugPrint('Code: ${e.code}');
      debugPrint('Message: ${e.message}');
      debugPrint('========================================');

      Get.snackbar(
        'Firebase Login Failed',
        e.message ??
            'Firebase authentication failed.',
        snackPosition: SnackPosition.BOTTOM,
        duration: const Duration(seconds: 5),
      );
    } on http.ClientException catch (e) {
      debugPrint('========================================');
      debugPrint('❌ Backend Connection Error');
      debugPrint('$e');
      debugPrint('========================================');

      Get.snackbar(
        'Server Connection Failed',
        'Could not connect to AiTradeX server.',
        snackPosition: SnackPosition.BOTTOM,
      );
    } catch (e, stackTrace) {
      debugPrint('========================================');
      debugPrint('❌ Google Login Error');
      debugPrint('Error: $e');
      debugPrint('StackTrace: $stackTrace');
      debugPrint('========================================');

      Get.snackbar(
        'Login Failed',
        e.toString().replaceFirst(
          'Exception: ',
          '',
        ),
        snackPosition: SnackPosition.BOTTOM,
        duration: const Duration(seconds: 5),
      );
    } finally {
      isLoading.value = false;
    }
  }

  Future<bool> _saveUserToBackend({
    required User user,
    required String firebaseIdToken,
  }) async {
    try {
      final Uri url = Uri.parse(
        '$_baseUrl/auth/google',
      );

      debugPrint('========================================');
      debugPrint('🔵 Saving Google user to backend');
      debugPrint('POST: $url');
      debugPrint('========================================');

      final response = await http
          .post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization':
          'Bearer $firebaseIdToken',
        },
        body: jsonEncode({
          'firebaseUid': user.uid,
        }),
      )
          .timeout(
        const Duration(seconds: 30),
      );

      debugPrint(
        'Backend status: ${response.statusCode}',
      );

      debugPrint(
        'Backend response: ${response.body}',
      );

      if (response.statusCode < 200 ||
          response.statusCode >= 300) {
        debugPrint(
          '❌ Backend Google login failed',
        );

        return false;
      }

      final dynamic decoded =
      jsonDecode(response.body);

      if (decoded is Map<String, dynamic>) {
        final bool success =
            decoded['success'] == true;

        if (!success) {
          debugPrint(
            '❌ Backend returned success=false',
          );

          return false;
        }
      }

      debugPrint(
        '✅ Google user saved to MongoDB',
      );

      return true;
    } on FormatException catch (e) {
      debugPrint(
        '❌ Invalid backend JSON response: $e',
      );

      return false;
    } catch (e, stackTrace) {
      debugPrint(
        '❌ Backend save error: $e',
      );

      debugPrint(
        'StackTrace: $stackTrace',
      );

      return false;
    }
  }

  Future<void> signOut() async {
    try {
      await _firebaseAuth.signOut();

      await _googleSignIn.signOut();

      debugPrint(
        '✅ Google and Firebase signed out',
      );
    } catch (e) {
      debugPrint(
        'Google sign out error: $e',
      );
    }
  }
}