import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../services/upstox_service.dart';

/// AiTradeX saved-report details screen.
///
/// Data flow:
///   My Reports -> MyReportsScreen -> UpstoxService.getReport()
///   -> AiTradeX backend -> Upstox
///
/// No Upstox secret or access token is stored in this screen.
class MyReportsScreen extends StatefulWidget {
  const MyReportsScreen({
    super.key,
    required this.symbol,
    required this.date,
    this.logo = '',
    this.company = '',
    this.report = '',
    this.remainingCoins = 0,
    this.instrumentKey,
    this.isin,
    this.onBuy,
  });

  final String symbol;
  final String date;
  final String logo;
  final String company;
  final String report;
  final int remainingCoins;
  final String? instrumentKey;
  final String? isin;
  final VoidCallback? onBuy;

  @override
  State<MyReportsScreen> createState() => _MyReportsScreenState();
}

class _MyReportsScreenState extends State<MyReportsScreen> {
  Map<String, dynamic>? _data;
  Object? _error;
  bool _loading = true;

  bool _financialsOpen = true;
  bool _priceVolumeOpen = true;
  bool _shareholdingOpen = true;
  bool _fundamentalsOpen = true;

  bool _revenueSelected = true;
  bool _yearlySelected = true;
  bool _returnsSelected = true;

  ThemeData get _theme => Theme.of(context);
  ColorScheme get _colors => _theme.colorScheme;
  Color get _primary => _colors.primary;
  Color get _background => _theme.scaffoldBackgroundColor;
  Color get _surface => _colors.surface;
  Color get _text => _colors.onSurface;
  Color get _muted => _colors.onSurface.withValues(alpha: .58);
  bool get _dark => _theme.brightness == Brightness.dark;

  Color get _secondary {
    final hsl = HSLColor.fromColor(_primary);
    return hsl
        .withHue((hsl.hue + 38) % 360)
        .withSaturation(
      (hsl.saturation + .08).clamp(0.0, 1.0).toDouble(),
    )
        .withLightness(_dark ? .58 : .48)
        .toColor();
  }

  LinearGradient get _gradient => LinearGradient(
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
    colors: <Color>[_primary, _secondary],
  );

  Map<String, dynamic> get _root {
    final response = _data ?? const <String, dynamic>{};
    final payload = _map(response['data']);

    // Your backend may wrap the report inside `data`.
    // Use the payload when it contains report fields; otherwise use the
    // response itself.
    if (payload.isNotEmpty &&
        (payload.containsKey('quote') ||
            payload.containsKey('financials') ||
            payload.containsKey('ratios') ||
            payload.containsKey('shareholding') ||
            payload.containsKey('returns') ||
            payload.containsKey('volumes'))) {
      return payload;
    }

    return response;
  }

  Map<String, dynamic> _map(dynamic value) {
    if (value is Map<String, dynamic>) return value;
    if (value is Map) return Map<String, dynamic>.from(value);
    return <String, dynamic>{};
  }

  dynamic _first(Map<String, dynamic> map, List<String> keys) {
    for (final key in keys) {
      if (map.containsKey(key) && map[key] != null) return map[key];
    }
    return null;
  }

  double _num(dynamic value, [double fallback = 0]) {
    if (value is num) return value.toDouble();
    if (value == null) return fallback;
    final cleaned = value
        .toString()
        .replaceAll(',', '')
        .replaceAll('₹', '')
        .replaceAll('%', '')
        .trim();
    return double.tryParse(cleaned) ?? fallback;
  }

  String _string(dynamic value, [String fallback = '']) {
    if (value == null) return fallback;
    return value.toString().trim();
  }

  Map<String, dynamic> get _quote {
    final quote = _map(_root['quote']);
    if (quote.isNotEmpty) return quote;

    final market = _map(_root['market']);
    if (market.isNotEmpty) return market;

    return _map(_root['data']);
  }

  Map<String, dynamic> get _ratios {
    final ratios = _map(
      _first(_root, <String>['ratios', 'ratio', 'fundamentals']),
    );
    return ratios;
  }

  Map<String, dynamic> get _financials {
    return _map(
      _first(_root, <String>['financials', 'financial', 'income_statement']),
    );
  }

  List<Map<String, dynamic>> _listMaps(dynamic value) {
    if (value is! List) return <Map<String, dynamic>>[];

    return value
        .whereType<Map>()
        .map((item) => Map<String, dynamic>.from(item))
        .toList();
  }

  List<Map<String, dynamic>> _history(String type) {
    final financials = _financials;

    dynamic raw;
    if (_yearlySelected) {
      raw = type == 'revenue'
          ? _first(
        financials,
        <String>['yearlyRevenue', 'revenue', 'annualRevenue'],
      )
          : _first(
        financials,
        <String>['yearlyNetProfit', 'netProfit', 'annualNetProfit'],
      );
    } else {
      raw = type == 'revenue'
          ? _first(
        financials,
        <String>['quarterlyRevenue', 'revenueQuarterly'],
      )
          : _first(
        financials,
        <String>['quarterlyNetProfit', 'netProfitQuarterly'],
      );
    }

    if (raw is List) return _listMaps(raw);

    final nested = _map(raw);
    if (nested.isNotEmpty) {
      return nested.entries.map((entry) {
        return <String, dynamic>{
          'period': entry.key,
          'value': entry.value,
        };
      }).toList();
    }

    return <Map<String, dynamic>>[];
  }

  List<Map<String, dynamic>> get _returns {
    final raw = _first(
      _root,
      <String>['returns', 'historicalReturns', 'pastReturns'],
    );

    if (raw is List) return _listMaps(raw);

    final map = _map(raw);
    if (map.isEmpty) return <Map<String, dynamic>>[];

    return map.entries
        .map(
          (entry) => <String, dynamic>{
        'period': entry.key,
        'value': entry.value,
      },
    )
        .toList();
  }

  List<Map<String, dynamic>> get _volumes {
    final raw = _first(
      _root,
      <String>['volumes', 'volumeHistory', 'historicalVolume', 'pastVolume'],
    );

    if (raw is List) return _listMaps(raw);

    final map = _map(raw);
    if (map.isEmpty) return <Map<String, dynamic>>[];

    return map.entries
        .map(
          (entry) => <String, dynamic>{
        'period': entry.key,
        'value': entry.value,
      },
    )
        .toList();
  }

  Map<String, dynamic> get _shareholding {
    return _map(
      _first(
        _root,
        <String>['shareholding', 'shareHoldings', 'holdings'],
      ),
    );
  }

  List<Map<String, dynamic>> get _holdingRows {
    final raw = _first(
      _shareholding,
      <String>['latest', 'latestQuarter', 'data', 'holders'],
    );

    if (raw is List) return _listMaps(raw);

    if (raw is Map) {
      return raw.entries
          .map(
            (entry) => <String, dynamic>{
          'category': entry.key,
          'value': entry.value,
        },
      )
          .toList();
    }

    if (_shareholding.isNotEmpty) {
      const keys = <String>[
        'promoters',
        'promoter',
        'fii',
        'foreignInstitutionalInvestors',
        'dii',
        'domesticInstitutionalInvestors',
        'mutual_funds',
        'mutualFunds',
        'retail_and_other',
        'retailAndOther',
        'public',
      ];

      return keys
          .where((key) => _shareholding.containsKey(key))
          .map(
            (key) => <String, dynamic>{
          'category': key,
          'value': _shareholding[key],
        },
      )
          .toList();
    }

    return <Map<String, dynamic>>[];
  }

  @override
  void initState() {
    super.initState();
    _loadReport();
  }

  Future<void> _loadReport() async {
    if (!mounted) return;

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final response = await UpstoxService.getReport(
        symbol: widget.symbol,
      );

      if (!mounted) return;

      setState(() {
        _data = response;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;

      setState(() {
        _error = error;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _background,
      appBar: AppBar(
        backgroundColor: _background,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          tooltip: 'Close',
          onPressed: () => Navigator.of(context).pop(),
          icon: Icon(Icons.close_rounded, color: _text),
        ),
        title: Text(
          'Report',
          style: GoogleFonts.poppins(
            color: _text,
            fontSize: 16,
            fontWeight: FontWeight.w700,
          ),
        ),
        actions: <Widget>[
          IconButton(
            tooltip: 'Refresh',
            onPressed: _loading ? null : _loadReport,
            icon: Icon(
              Icons.refresh_rounded,
              color: _loading ? _muted : _primary,
            ),
          ),
        ],
      ),
      body: SafeArea(
        top: false,
        child: Stack(
          children: <Widget>[
            RefreshIndicator(
              color: _primary,
              onRefresh: _loadReport,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(
                  parent: BouncingScrollPhysics(),
                ),
                padding: const EdgeInsets.fromLTRB(14, 2, 14, 120),
                children: <Widget>[
                  _buildHeader(),
                  const SizedBox(height: 12),
                  if (_loading)
                    _buildLoading()
                  else if (_data == null)
                    _buildError()
                  else ...<Widget>[
                      _buildFundamentals(),
                      const SizedBox(height: 12),
                      _buildFinancials(),
                      const SizedBox(height: 12),
                      _buildPriceVolume(),
                      const SizedBox(height: 12),
                      _buildShareholding(),
                      const SizedBox(height: 12),
                      _buildTextAnalysis(),
                      const SizedBox(height: 18),
                      _buildDisclaimer(),
                    ],
                ],
              ),
            ),
            _buildBottomAction(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    final lastPrice = _num(
      _first(
        _quote,
        <String>['last_price', 'lastPrice', 'ltp', 'last_traded_price'],
      ),
    );
    final changePercent = _num(
      _first(
        _quote,
        <String>['change_percent', 'changePercent', 'percent_change'],
      ),
    );
    final previousClose = _num(
      _first(
        _quote,
        <String>['previous_close', 'previousClose', 'prev_close'],
      ),
    );
    final dayChange = _num(
      _first(_quote, <String>['change', 'day_change', 'dayChange']),
      lastPrice - previousClose,
    );
    final volume = _num(
      _first(_quote, <String>['volume', 'total_volume']),
    );
    final positive = changePercent >= 0;

    final apiSymbol = _string(
      _first(_root, <String>['symbol', 'trading_symbol']),
      widget.symbol,
    );
    final apiName = _string(
      _first(_root, <String>['company', 'companyName', 'name']),
    );
    final title = widget.company.trim().isNotEmpty
        ? widget.company.trim()
        : (apiName.isNotEmpty ? apiName : widget.symbol);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            _primary.withValues(alpha: _dark ? .24 : .12),
            _surface,
          ],
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: _primary.withValues(alpha: .16),
        ),
      ),
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              _logo(),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.poppins(
                        color: _text,
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '$apiSymbol • Upstox market data',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.poppins(
                        color: _muted,
                        fontSize: 9.5,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    if (widget.date.trim().isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 3),
                        child: Text(
                          widget.date,
                          style: GoogleFonts.poppins(
                            color: _muted,
                            fontSize: 8.5,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              _smallIcon(
                _loading
                    ? Icons.sync_rounded
                    : Icons.auto_awesome_rounded,
              ),
            ],
          ),
          if (_data != null) ...<Widget>[
            const SizedBox(height: 14),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Text(
                  _money(lastPrice),
                  style: GoogleFonts.poppins(
                    color: _text,
                    fontSize: 28,
                    height: 1,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(width: 9),
                Padding(
                  padding: const EdgeInsets.only(bottom: 2),
                  child: Text(
                    '${positive ? '+' : ''}${changePercent.toStringAsFixed(2)}%',
                    style: GoogleFonts.poppins(
                      color: positive ? Colors.green : Colors.redAccent,
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 7),
            Row(
              children: <Widget>[
                Expanded(
                  child: _miniStat(
                    'Day change',
                    '${dayChange >= 0 ? '+' : ''}${_money(dayChange)}',
                    dayChange >= 0 ? Colors.green : Colors.redAccent,
                  ),
                ),
                const SizedBox(width: 7),
                Expanded(
                  child: _miniStat(
                    'Previous close',
                    _money(previousClose),
                    null,
                  ),
                ),
                const SizedBox(width: 7),
                Expanded(
                  child: _miniStat(
                    'Volume',
                    _compactNumber(volume),
                    null,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _logo() {
    final value = widget.logo.trim();
    if (value.startsWith('http://') || value.startsWith('https://')) {
      return ClipOval(
        child: Image.network(
          value,
          width: 48,
          height: 48,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => _logoFallback(),
        ),
      );
    }

    if (value.isNotEmpty) {
      return Container(
        width: 48,
        height: 48,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: _primary.withValues(alpha: .12),
          shape: BoxShape.circle,
        ),
        child: Text(
          value,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: GoogleFonts.poppins(
            color: _primary,
            fontSize: 10,
            fontWeight: FontWeight.w800,
          ),
        ),
      );
    }

    return _logoFallback();
  }

  Widget _logoFallback() {
    final symbol = widget.symbol.trim().toUpperCase();
    final initials = symbol.length > 3 ? symbol.substring(0, 3) : symbol;

    return Container(
      width: 48,
      height: 48,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: _primary.withValues(alpha: .12),
        shape: BoxShape.circle,
        border: Border.all(
          color: _primary.withValues(alpha: .22),
        ),
      ),
      child: Text(
        initials.isEmpty ? 'AI' : initials,
        style: GoogleFonts.poppins(
          color: _primary,
          fontSize: 10,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }

  Widget _buildLoading() {
    return _reportCard(
      title: 'Loading live report',
      icon: Icons.sync_rounded,
      expanded: true,
      onToggle: null,
      child: Column(
        children: <Widget>[
          LinearProgressIndicator(
            minHeight: 4,
            borderRadius: BorderRadius.circular(4),
            color: _primary,
            backgroundColor: _colors.surfaceContainerHighest,
          ),
          const SizedBox(height: 16),
          Text(
            'Loading live price, financials, ratios and shareholding from Upstox…',
            textAlign: TextAlign.center,
            style: GoogleFonts.poppins(
              color: _muted,
              fontSize: 11,
              height: 1.45,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildError() {
    return _reportCard(
      title: 'Market data unavailable',
      icon: Icons.cloud_off_rounded,
      expanded: true,
      onToggle: null,
      child: Column(
        children: <Widget>[
          Text(
            _errorMessage(),
            textAlign: TextAlign.center,
            style: GoogleFonts.poppins(
              color: _muted,
              fontSize: 11,
              height: 1.45,
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            height: 46,
            child: ElevatedButton.icon(
              onPressed: _loadReport,
              style: ElevatedButton.styleFrom(
                backgroundColor: _primary,
                foregroundColor: _colors.onPrimary,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              icon: const Icon(Icons.refresh_rounded),
              label: Text(
                'Retry',
                style: GoogleFonts.poppins(fontWeight: FontWeight.w700),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _errorMessage() {
    if (_error == null) {
      return 'Live report data is unavailable right now.';
    }

    return _error
        .toString()
        .replaceFirst('Exception: ', '')
        .replaceFirst('ReportApiException: ', '');
  }

  Widget _buildFundamentals() {
    final ratios = _ratios;
    final isin = _string(
      _first(
        _root,
        <String>['isin', 'instrument_isin'],
      ),
      widget.isin ?? '',
    );

    return _reportCard(
      title: 'Fundamentals',
      icon: Icons.bolt_rounded,
      expanded: _fundamentalsOpen,
      onToggle: () {
        setState(() => _fundamentalsOpen = !_fundamentalsOpen);
      },
      child: Column(
        children: <Widget>[
          _pillRow(<String>[
            _string(
              _first(_root, <String>['sector', 'industry']),
              'NSE Equity',
            ),
            isin.isEmpty ? 'Live fundamentals' : isin,
          ]),
          const SizedBox(height: 12),
          Row(
            children: <Widget>[
              Expanded(child: _metric('P/E', _ratio(ratios, <String>['pe', 'p_e']))),
              const SizedBox(width: 7),
              Expanded(
                child: _metric(
                  'Sector P/E',
                  _ratio(ratios, <String>['sector_pe', 'sectorPe', 'sector_p_e']),
                ),
              ),
            ],
          ),
          const SizedBox(height: 7),
          Row(
            children: <Widget>[
              Expanded(child: _metric('P/B', _ratio(ratios, <String>['pb', 'p_b']))),
              const SizedBox(width: 7),
              Expanded(child: _metric('ROE', _ratio(ratios, <String>['roe']))),
            ],
          ),
          const SizedBox(height: 7),
          Row(
            children: <Widget>[
              Expanded(child: _metric('ROCE', _ratio(ratios, <String>['roce']))),
              const SizedBox(width: 7),
              Expanded(
                child: _metric(
                  'EV/EBITDA',
                  _ratio(ratios, <String>['ev_ebitda', 'evEbitda']),
                ),
              ),
            ],
          ),
          const SizedBox(height: 9),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Ratios are supplied by the AiTradeX backend / Upstox.',
              style: GoogleFonts.poppins(
                color: _muted,
                fontSize: 8,
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _ratio(Map<String, dynamic> ratios, List<String> keys) {
    final value = _first(ratios, keys);
    if (value == null) return '—';

    final number = _num(value, double.nan);
    if (!number.isFinite) return '—';

    return number.toStringAsFixed(2);
  }

  Widget _buildFinancials() {
    final type = _revenueSelected ? 'revenue' : 'profit';
    final rows = _history(type);

    return _reportCard(
      title: 'Financials',
      icon: Icons.bar_chart_rounded,
      expanded: _financialsOpen,
      onToggle: () {
        setState(() => _financialsOpen = !_financialsOpen);
      },
      child: Column(
        children: <Widget>[
          _segmented(
            first: 'Revenue',
            second: 'Net profit',
            firstSelected: _revenueSelected,
            onFirst: () => setState(() => _revenueSelected = true),
            onSecond: () => setState(() => _revenueSelected = false),
          ),
          const SizedBox(height: 16),
          Align(
            alignment: Alignment.centerRight,
            child: Text(
              '₹ Cr • Upstox Fundamentals',
              style: GoogleFonts.poppins(
                color: _muted,
                fontSize: 9,
              ),
            ),
          ),
          const SizedBox(height: 8),
          if (rows.isEmpty)
            _emptyData('No ${_yearlySelected ? 'yearly' : 'quarterly'} financial data returned by Upstox.')
          else
            SizedBox(
              height: 210,
              child: _financialChart(rows),
            ),
          const SizedBox(height: 12),
          _segmented(
            first: 'Yearly',
            second: 'Quarterly',
            firstSelected: _yearlySelected,
            onFirst: () => setState(() => _yearlySelected = true),
            onSecond: () => setState(() => _yearlySelected = false),
            compact: true,
          ),
        ],
      ),
    );
  }

  Widget _financialChart(List<Map<String, dynamic>> rows) {
    final visible = rows.length > 6
        ? rows.sublist(rows.length - 6)
        : rows;

    final values = visible.map((row) {
      return _num(_first(row, <String>['value', 'amount', 'revenue', 'net_profit']));
    }).toList();

    final maxValue = values.fold<double>(
      0,
          (maxValue, value) => math.max(maxValue, value.abs()),
    );

    if (maxValue <= 0) {
      return _emptyData('No numeric financial values available.');
    }

    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: List<Widget>.generate(visible.length, (index) {
        final row = visible[index];
        final value = values[index];
        final factor = (value.abs() / maxValue).clamp(0.08, 1.0).toDouble();
        final height = 105 * factor;
        final period = _string(
          _first(row, <String>['period', 'year', 'quarter', 'label']),
          '—',
        );

        return Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 3),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                Text(
                  _compactNumber(value.abs()),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.poppins(
                    color: _text,
                    fontSize: 7,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 5),
                Container(
                  height: height,
                  decoration: BoxDecoration(
                    gradient: _gradient,
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(7),
                    ),
                  ),
                ),
                const SizedBox(height: 7),
                Text(
                  period.replaceAll(' ', '\n'),
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  style: GoogleFonts.poppins(
                    color: _muted,
                    fontSize: 7,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        );
      }),
    );
  }

  Widget _buildPriceVolume() {
    return _reportCard(
      title: 'Price & volume',
      icon: Icons.currency_rupee_rounded,
      expanded: _priceVolumeOpen,
      onToggle: () {
        setState(() => _priceVolumeOpen = !_priceVolumeOpen);
      },
      child: Column(
        children: <Widget>[
          _segmented(
            first: 'Past returns',
            second: 'Past volume',
            firstSelected: _returnsSelected,
            onFirst: () => setState(() => _returnsSelected = true),
            onSecond: () => setState(() => _returnsSelected = false),
          ),
          const SizedBox(height: 16),
          if (_returnsSelected)
            _returnsBars()
          else
            _volumeBars(),
        ],
      ),
    );
  }

  Widget _returnsBars() {
    final rows = _returns
        .map(
          (row) => <String, dynamic>{
        'period': _string(
          _first(row, <String>['period', 'label', 'range']),
          '—',
        ),
        'value': _num(_first(row, <String>['value', 'return', 'return_percent', 'change_percent'])),
      },
    )
        .toList();

    if (rows.isEmpty) {
      return _emptyData('No historical return data available.');
    }

    final maxAbs = rows.fold<double>(
      1,
          (maxValue, row) => math.max(maxValue, _num(row['value']).abs()),
    );

    return Column(
      children: rows.map((row) {
        final value = _num(row['value']);
        final positive = value >= 0;
        final factor = (value.abs() / maxAbs).clamp(0.03, 1.0).toDouble();

        return Padding(
          padding: const EdgeInsets.only(bottom: 11),
          child: Row(
            children: <Widget>[
              SizedBox(
                width: 42,
                child: Text(
                  _string(row['period'], '—'),
                  style: GoogleFonts.poppins(
                    color: _muted,
                    fontSize: 8,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              Expanded(
                child: Container(
                  height: 18,
                  decoration: BoxDecoration(
                    color: _colors.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(9),
                  ),
                  alignment: Alignment.centerLeft,
                  child: FractionallySizedBox(
                    widthFactor: factor,
                    child: Container(
                      decoration: BoxDecoration(
                        color: positive ? _primary : Colors.redAccent,
                        borderRadius: BorderRadius.circular(9),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 9),
              SizedBox(
                width: 54,
                child: Text(
                  '${positive ? '+' : ''}${value.toStringAsFixed(2)}%',
                  textAlign: TextAlign.right,
                  style: GoogleFonts.poppins(
                    color: positive ? Colors.green : Colors.redAccent,
                    fontSize: 8.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _volumeBars() {
    final rows = _volumes
        .map(
          (row) => <String, dynamic>{
        'period': _string(
          _first(row, <String>['period', 'label', 'date']),
          '—',
        ),
        'value': _num(_first(row, <String>['value', 'volume', 'qty'])),
      },
    )
        .where((row) => _num(row['value']) > 0)
        .toList();

    if (rows.isEmpty) {
      return _emptyData('No historical volume data available.');
    }

    final maxValue = rows.fold<double>(
      1,
          (maxValue, row) => math.max(maxValue, _num(row['value'])),
    );

    return Column(
      children: rows.map((row) {
        final value = _num(row['value']);
        final factor = (value / maxValue).clamp(0.03, 1.0).toDouble();

        return Padding(
          padding: const EdgeInsets.only(bottom: 11),
          child: Row(
            children: <Widget>[
              SizedBox(
                width: 42,
                child: Text(
                  _string(row['period'], '—'),
                  style: GoogleFonts.poppins(
                    color: _muted,
                    fontSize: 8,
                  ),
                ),
              ),
              Expanded(
                child: Container(
                  height: 18,
                  decoration: BoxDecoration(
                    color: _colors.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(9),
                  ),
                  alignment: Alignment.centerLeft,
                  child: FractionallySizedBox(
                    widthFactor: factor,
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: _gradient,
                        borderRadius: BorderRadius.circular(9),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 9),
              SizedBox(
                width: 54,
                child: Text(
                  _compactNumber(value),
                  textAlign: TextAlign.right,
                  style: GoogleFonts.poppins(
                    color: _text,
                    fontSize: 8,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildShareholding() {
    final rows = _holdingRows;

    if (rows.isEmpty) {
      return _reportCard(
        title: 'Shareholding',
        icon: Icons.pie_chart_rounded,
        expanded: _shareholdingOpen,
        onToggle: () {
          setState(() => _shareholdingOpen = !_shareholdingOpen);
        },
        child: _emptyData('No shareholding data available from Upstox.'),
      );
    }

    final values = rows
        .map((row) => _num(_first(row, <String>['value', 'percentage', 'percent'])))
        .toList();
    final colors = _shareColors(values.length);
    final total = values.fold<double>(0, (sum, value) => sum + value);
    final period = _string(
      _first(_shareholding, <String>['period', 'date', 'quarter']),
      'Latest quarter',
    );

    return _reportCard(
      title: 'Shareholding',
      icon: Icons.pie_chart_rounded,
      expanded: _shareholdingOpen,
      onToggle: () {
        setState(() => _shareholdingOpen = !_shareholdingOpen);
      },
      child: Column(
        children: <Widget>[
          Text(
            period,
            style: GoogleFonts.poppins(
              color: _text,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 190,
            child: CustomPaint(
              painter: _DonutPainter(
                values: values,
                colors: colors,
                background: _colors.surfaceContainerHighest,
              ),
              child: Center(
                child: Text(
                  '${total.toStringAsFixed(1)}%',
                  style: GoogleFonts.poppins(
                    color: _text,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            alignment: WrapAlignment.center,
            spacing: 12,
            runSpacing: 8,
            children: List<Widget>.generate(rows.length, (index) {
              final label = _shareLabel(
                _string(
                  _first(rows[index], <String>['category', 'type', 'name']),
                  'Other',
                ),
              );
              return _legend(
                label,
                colors[index],
                '${values[index].toStringAsFixed(2)}%',
              );
            }),
          ),
        ],
      ),
    );
  }

  List<Color> _shareColors(int count) {
    final colors = <Color>[
      _primary,
      _secondary,
      Colors.orange,
      Colors.pinkAccent,
      Colors.blueAccent,
      Colors.teal,
    ];

    return List<Color>.generate(
      count,
          (index) => colors[index % colors.length],
    );
  }

  String _shareLabel(String value) {
    switch (value.toLowerCase()) {
      case 'fii':
      case 'foreign_institutional_investors':
      case 'foreigninstitutionalinvestors':
        return 'FII';
      case 'dii':
      case 'domestic_institutional_investors':
      case 'domesticinstitutionalinvestors':
        return 'DII';
      case 'mutual_funds':
      case 'mutualfunds':
        return 'Mutual funds';
      case 'retail_and_other':
      case 'retailandother':
        return 'Retail & other';
      case 'promoters':
      case 'promoter':
        return 'Promoters';
      case 'public':
        return 'Public';
      default:
        return value;
    }
  }

  Widget _buildTextAnalysis() {
    final sections = _parseReport(widget.report);

    if (sections.isEmpty) {
      return _reportCard(
        title: 'AI analysis',
        icon: Icons.auto_awesome_rounded,
        expanded: true,
        onToggle: null,
        child: Text(
          'No detailed AI report content is available for this saved report.',
          style: GoogleFonts.poppins(
            color: _muted,
            fontSize: 11.5,
            height: 1.55,
          ),
        ),
      );
    }

    return Column(
      children: sections.map((section) {
        final risk = section.title.toLowerCase().contains('risk');

        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: _analysisCard(section, isRisk: risk),
        );
      }).toList(),
    );
  }

  Widget _analysisCard(
      _ReportSection section, {
        bool isRisk = false,
      }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(14, 15, 14, 16),
      decoration: BoxDecoration(
        color: _surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: _colors.onSurface.withValues(alpha: .07),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          ShaderMask(
            shaderCallback: (bounds) => _gradient.createShader(bounds),
            child: Text(
              section.title,
              style: GoogleFonts.poppins(
                color: Colors.white,
                fontSize: 18,
                height: 1.05,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(height: 10),
          ...section.points.map(
                (point) => Padding(
              padding: const EdgeInsets.only(bottom: 9),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Icon(
                      Icons.circle,
                      size: 5,
                      color: isRisk ? Colors.orange : _primary,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      point,
                      style: GoogleFonts.poppins(
                        color: _text,
                        fontSize: 10.5,
                        height: 1.45,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _reportCard({
    required String title,
    required IconData icon,
    required bool expanded,
    required VoidCallback? onToggle,
    required Widget child,
  }) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(14, 15, 14, 16),
      decoration: BoxDecoration(
        color: _surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: _colors.onSurface.withValues(alpha: .055),
        ),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: Colors.black.withValues(alpha: _dark ? .18 : .04),
            blurRadius: 16,
            offset: const Offset(0, 7),
          ),
        ],
      ),
      child: Column(
        children: <Widget>[
          InkWell(
            onTap: onToggle,
            borderRadius: BorderRadius.circular(12),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: Row(
                children: <Widget>[
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      color: _primary.withValues(alpha: .11),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(icon, color: _primary, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      title,
                      style: GoogleFonts.poppins(
                        color: _text,
                        fontSize: 15.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  Icon(
                    expanded
                        ? Icons.keyboard_arrow_up_rounded
                        : Icons.keyboard_arrow_down_rounded,
                    color: _text,
                    size: 25,
                  ),
                ],
              ),
            ),
          ),
          if (expanded) ...<Widget>[
            const SizedBox(height: 16),
            child,
          ],
        ],
      ),
    );
  }

  Widget _segmented({
    required String first,
    required String second,
    required bool firstSelected,
    required VoidCallback onFirst,
    required VoidCallback onSecond,
    bool compact = false,
  }) {
    return Container(
      height: compact ? 54 : 58,
      padding: const EdgeInsets.all(5),
      decoration: BoxDecoration(
        color: _colors.surfaceContainerHighest.withValues(alpha: .72),
        borderRadius: BorderRadius.circular(30),
      ),
      child: Row(
        children: <Widget>[
          Expanded(
            child: _segment(
              first,
              selected: firstSelected,
              onTap: onFirst,
            ),
          ),
          Expanded(
            child: _segment(
              second,
              selected: !firstSelected,
              onTap: onSecond,
            ),
          ),
        ],
      ),
    );
  }

  Widget _segment(
      String text, {
        required bool selected,
        required VoidCallback onTap,
      }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          gradient: selected ? _gradient : null,
          borderRadius: BorderRadius.circular(26),
        ),
        child: Text(
          text,
          style: GoogleFonts.poppins(
            color: selected ? Colors.white : _text,
            fontSize: 10.5,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    );
  }

  Widget _pillRow(List<String> items) {
    return Row(
      children: items.asMap().entries.map((entry) {
        final last = entry.key == items.length - 1;

        return Expanded(
          child: Container(
            margin: EdgeInsets.only(right: last ? 0 : 5),
            padding: const EdgeInsets.symmetric(
              horizontal: 7,
              vertical: 8,
            ),
            decoration: BoxDecoration(
              color: _primary.withValues(alpha: .10),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: _primary.withValues(alpha: .20),
              ),
            ),
            child: Text(
              entry.value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: GoogleFonts.poppins(
                color: _primary,
                fontSize: 7.8,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _metric(String title, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 10),
      decoration: BoxDecoration(
        color: _colors.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            title,
            style: GoogleFonts.poppins(
              color: _muted,
              fontSize: 7.5,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.poppins(
              color: _text,
              fontSize: 10,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }

  Widget _miniStat(String title, String value, Color? valueColor) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      decoration: BoxDecoration(
        color: _colors.surfaceContainerHighest.withValues(alpha: .72),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.poppins(
              color: _muted,
              fontSize: 6.7,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.poppins(
              color: valueColor ?? _text,
              fontSize: 8.5,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }

  Widget _legend(String label, Color color, String value) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Container(
          width: 7,
          height: 7,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
          ),
        ),
        const SizedBox(width: 5),
        Text(
          '$label $value',
          style: GoogleFonts.poppins(
            color: _muted,
            fontSize: 7.2,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Widget _smallIcon(IconData icon) {
    return Container(
      width: 34,
      height: 34,
      decoration: BoxDecoration(
        color: _primary.withValues(alpha: .10),
        shape: BoxShape.circle,
      ),
      child: Icon(icon, color: _primary, size: 17),
    );
  }

  Widget _emptyData(String message) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _colors.surfaceContainerHighest.withValues(alpha: .65),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        message,
        textAlign: TextAlign.center,
        style: GoogleFonts.poppins(
          color: _muted,
          fontSize: 9.5,
          height: 1.4,
        ),
      ),
    );
  }

  Widget _buildBottomAction() {
    return Positioned(
      left: 0,
      right: 0,
      bottom: 0,
      child: Container(
        padding: const EdgeInsets.fromLTRB(12, 9, 14, 12),
        decoration: BoxDecoration(
          color: _background.withValues(alpha: .96),
          border: Border(
            top: BorderSide(
              color: _colors.onSurface.withValues(alpha: .06),
            ),
          ),
        ),
        child: Row(
          children: <Widget>[
            Container(
              width: 54,
              height: 54,
              decoration: BoxDecoration(
                color: _colors.surfaceContainerHighest,
                shape: BoxShape.circle,
                border: Border.all(
                  color: _colors.onSurface.withValues(alpha: .15),
                ),
              ),
              child: Icon(
                Icons.savings_rounded,
                color: _primary,
                size: 24,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: SizedBox(
                height: 54,
                child: ElevatedButton(
                  onPressed: widget.onBuy ?? _defaultBuy,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _primary,
                    foregroundColor: _colors.onPrimary,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(17),
                    ),
                  ),
                  child: Text(
                    'Buy now',
                    style: GoogleFonts.poppins(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _defaultBuy() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Connect your existing Upstox order flow here.',
          style: GoogleFonts.poppins(fontSize: 11),
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Widget _buildDisclaimer() {
    return Text(
      'Market data is supplied by Upstox. AI-generated information is educational only and does not guarantee investment returns.',
      textAlign: TextAlign.center,
      style: GoogleFonts.poppins(
        color: _muted,
        fontSize: 8.5,
        height: 1.45,
      ),
    );
  }

  List<_ReportSection> _parseReport(String raw) {
    final text = raw.trim();
    if (text.isEmpty) return <_ReportSection>[];

    const headings = <String>[
      'Overview',
      'Fundamental insights',
      'Fundamental Insights',
      'Risks & Trade Plan',
      'Risks and Trade Plan',
      'Recent News Drivers',
      'Recent News',
      'Key Risks',
      'Technical Analysis',
      'Investment View',
    ];

    final result = <_ReportSection>[];
    String? currentTitle;
    final points = <String>[];

    void flush() {
      if (currentTitle != null && points.isNotEmpty) {
        result.add(
          _ReportSection(
            title: currentTitle!,
            points: List<String>.from(points),
          ),
        );
      }
      points.clear();
    }

    final lines = text
        .split(RegExp(r'\r?\n'))
        .map((line) => line.trim())
        .where((line) => line.isNotEmpty)
        .toList();

    for (final line in lines) {
      final normalized = line
          .replaceAll(RegExp(r'^[#*\-\s]+'), '')
          .trim();

      String? heading;
      for (final item in headings) {
        if (normalized.toLowerCase() == item.toLowerCase()) {
          heading = item;
          break;
        }
      }

      if (heading != null) {
        flush();
        currentTitle = heading;
        continue;
      }

      currentTitle ??= 'AI analysis';

      final clean = normalized.replaceFirst(
        RegExp(r'^[•●▪◦]\s*'),
        '',
      );

      if (clean.isNotEmpty) points.add(clean);
    }

    flush();

    if (result.isEmpty) {
      return <_ReportSection>[
        _ReportSection(
          title: 'AI analysis',
          points: <String>[text],
        ),
      ];
    }

    return result;
  }

  String _money(double value) {
    if (!value.isFinite || value == 0) return '—';
    return '₹${value.toStringAsFixed(2)}';
  }

  String _compactNumber(double value) {
    if (!value.isFinite) return '—';

    final abs = value.abs();
    if (abs >= 10000000) {
      return '${(value / 10000000).toStringAsFixed(2)} Cr';
    }
    if (abs >= 100000) {
      return '${(value / 100000).toStringAsFixed(2)} L';
    }
    if (abs >= 1000) {
      return '${(value / 1000).toStringAsFixed(1)}K';
    }
    return value.toStringAsFixed(0);
  }
}

class _ReportSection {
  const _ReportSection({
    required this.title,
    required this.points,
  });

  final String title;
  final List<String> points;
}

class _DonutPainter extends CustomPainter {
  const _DonutPainter({
    required this.values,
    required this.colors,
    required this.background,
  });

  final List<double> values;
  final List<Color> colors;
  final Color background;

  @override
  void paint(Canvas canvas, Size size) {
    final total = values.fold<double>(
      0,
          (sum, value) => sum + value,
    );

    if (total <= 0) return;

    final radius = size.shortestSide * .32;
    final stroke = radius * .42;
    final center = size.center(Offset.zero);

    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.butt;

    var start = -math.pi / 2;

    for (var i = 0; i < values.length; i++) {
      final sweep = (values[i] / total) * math.pi * 2;
      paint.color = colors[i % colors.length];

      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        start,
        math.max(0, sweep - .025),
        false,
        paint,
      );

      start += sweep;
    }

    paint
      ..color = background.withValues(alpha: .45)
      ..strokeWidth = 1;

    canvas.drawCircle(
      center,
      radius - stroke * .53,
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant _DonutPainter oldDelegate) {
    return oldDelegate.values != values ||
        oldDelegate.colors != colors ||
        oldDelegate.background != background;
  }
}