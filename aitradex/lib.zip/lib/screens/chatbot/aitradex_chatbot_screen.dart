import 'dart:convert';
import 'dart:math' as math;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:aitradex/screens/stockDetails/stock_ai_report_questions.dart';
import 'package:aitradex/screens/chatbot/myreports_screen.dart';

/// AiTradeX AI chatbot home + chat screen.
///
/// Visual reference: LiMo-style AI assistant home supplied by the user.
///
/// UI is inspired by the supplied LiMo reference:
/// - compact profile/coin header
/// - AI hero section
/// - stock/market quick actions
/// - Stock reports / Portfolio reports tabs
/// - My reports list
/// - Most asked reports
/// - Potential stocks section
/// - no bottom navigation on the chatbot screen
///
/// Chat flow:
/// Flutter -> Firebase ID token -> AiTradeX backend -> AI service -> Flutter.
///
/// IMPORTANT: The AI provider API key must stay on the backend.
class AiTradeXChatbotScreen extends StatefulWidget {
  const AiTradeXChatbotScreen({super.key});

  @override
  State<AiTradeXChatbotScreen> createState() => _AiTradeXChatbotScreenState();
}

class _AiTradeXChatbotScreenState extends State<AiTradeXChatbotScreen> {
  static const String _apiBaseUrl =
      'https://aitradex-api.onrender.com/api';

  static const Color _green = Color(0xFF18C48F);
  static const Color _pink = Color(0xFFFF159B);
  static const Color _orange = Color(0xFFFFB52E);

  final TextEditingController _messageController =
  TextEditingController();
  final ScrollController _scrollController = ScrollController();

  final List<_ChatMessage> _messages = <_ChatMessage>[
    const _ChatMessage(
      text:
      'Hi! I’m AiTradeX AI. Ask me about stocks, markets, ETFs, mutual funds, commodities, portfolio concepts, or investing terms.',
      isUser: false,
    ),
  ];


  final List<_ReportItem> _reports = <_ReportItem>[];

  //noinspection SpellCheckingInspection
  final List<_AskedReport> _mostAsked = const <_AskedReport>[
    _AskedReport('POLICYBZR', '767 requests', 'today', 'PB'),
    _AskedReport('BEL', '706 requests', 'today', 'BEL'),
    _AskedReport('SHRIRAM', '677 requests', 'today', 'S'),
  ];

  //noinspection SpellCheckingInspection
  final List<_PotentialStock> _potentialStocks = const <_PotentialStock>[
    _PotentialStock('RELIANCE', '9%', 'Potential upside'),
    _PotentialStock('HDFCBANK', '5%', 'Potential upside'),
  ];

  bool _isLoading = false;
  final ValueNotifier<int> _chatVersion = ValueNotifier<int>(0);
  bool _showPortfolioReports = false;
  int _coinBalance = 0;
  bool _isCoinLoading = true;

  ThemeData get _theme => Theme.of(context);
  Color get _primary => _theme.colorScheme.primary;
  Color get _background => _theme.scaffoldBackgroundColor;
  Color get _surface => _theme.colorScheme.surface;
  Color get _onSurface => _theme.colorScheme.onSurface;
  Color get _muted => _onSurface.withValues(alpha: .62);

  @override
  void initState() {
    super.initState();
    _loadCoinBalance();
    _loadSavedReports();
  }

  Future<void> _loadCoinBalance() async {
    if (!mounted) return;
    setState(() => _isCoinLoading = true);

    try {
      final User? user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        if (mounted) setState(() => _coinBalance = 0);
        return;
      }

      final String? token = await user.getIdToken(true);
      if (token == null || token.trim().isEmpty) return;

      final http.Response response = await http.get(
        Uri.parse('$_apiBaseUrl/coins/balance'),
        headers: <String, String>{
          'Accept': 'application/json',
          'Authorization': 'Bearer ${token.trim()}',
        },
      ).timeout(const Duration(seconds: 20));

      if (response.statusCode < 200 || response.statusCode >= 300) {
        debugPrint('Coin balance request failed: ${response.statusCode} ${response.body}');
        return;
      }

      final dynamic decoded = jsonDecode(response.body);
      if (decoded is! Map<String, dynamic>) return;

      dynamic rawBalance;
      final dynamic data = decoded['data'];
      if (data is Map<String, dynamic>) {
        rawBalance = data['balance'] ?? data['coins'];
      }
      rawBalance ??= decoded['balance'] ?? decoded['coins'];

      final int balance = rawBalance is num
          ? rawBalance.toInt()
          : int.tryParse(rawBalance?.toString() ?? '') ?? 0;

      if (mounted) setState(() => _coinBalance = balance < 0 ? 0 : balance);
    } catch (error, stackTrace) {
      debugPrint('AiTradeX coin balance error: $error');
      debugPrintStack(stackTrace: stackTrace);
    } finally {
      if (mounted) setState(() => _isCoinLoading = false);
    }
  }

  String? _reportStorageKey() {
    final User? user = FirebaseAuth.instance.currentUser;
    final String? uid = user?.uid;
    if (uid == null || uid.trim().isEmpty) return null;
    return 'aitradex_my_reports_${uid.trim()}';
  }

  Future<void> _loadSavedReports() async {
    try {
      final String? key = _reportStorageKey();
      if (key == null) return;

      final SharedPreferences prefs = await SharedPreferences.getInstance();
      final List<String> raw = prefs.getStringList(key) ?? <String>[];
      final List<_ReportItem> loaded = <_ReportItem>[];

      for (final String item in raw) {
        try {
          final dynamic decoded = jsonDecode(item);
          if (decoded is! Map) continue;
          loaded.add(_ReportItem.fromJson(Map<String, dynamic>.from(decoded)));
        } catch (_) {
          // Ignore one malformed saved report instead of breaking the screen.
        }
      }

      if (!mounted) return;
      setState(() {
        _reports
          ..clear()
          ..addAll(loaded);
      });
    } catch (error) {
      debugPrint('AiTradeX saved reports load error: $error');
    }
  }

  Future<void> _saveReport(_ReportItem report) async {
    try {
      final String? key = _reportStorageKey();
      if (key == null) return;

      final SharedPreferences prefs = await SharedPreferences.getInstance();
      final List<String> raw = prefs.getStringList(key) ?? <String>[];

      final List<_ReportItem> reports = <_ReportItem>[];
      for (final String item in raw) {
        try {
          final dynamic decoded = jsonDecode(item);
          if (decoded is Map) {
            reports.add(_ReportItem.fromJson(Map<String, dynamic>.from(decoded)));
          }
        } catch (_) {}
      }

      reports.removeWhere(
            (item) => item.symbol.toUpperCase() == report.symbol.toUpperCase(),
      );
      reports.insert(0, report);
      if (reports.length > 30) {
        reports.removeRange(30, reports.length);
      }

      await prefs.setStringList(
        key,
        reports.map((item) => jsonEncode(item.toJson())).toList(),
      );

      if (!mounted) return;
      setState(() {
        _reports
          ..clear()
          ..addAll(reports);
      });
    } catch (error) {
      debugPrint('AiTradeX saved report error: $error');
    }
  }

  void _openSavedReport(_ReportItem item) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => MyReportsScreen(
          symbol: item.symbol,
          date: item.date,
          logo: item.logo,
          company: item.company,
          report: item.report,
          remainingCoins: item.remainingCoins,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    _chatVersion.dispose();
    super.dispose();
  }

  Future<void> _sendMessage([String? predefinedMessage]) async {
    final String text =
    (predefinedMessage ?? _messageController.text).trim();

    if (text.isEmpty || _isLoading) {
      return;
    }

    FocusManager.instance.primaryFocus?.unfocus();
    final List<Map<String, String>> history = _buildHistory();

    setState(() {
      _messages.add(_ChatMessage(text: text, isUser: true));
      _messageController.clear();
      _isLoading = true;
    });
    _chatVersion.value++;

    await _scrollToBottom();

    try {
      final String reply = await _requestAiResponse(
        message: text,
        history: history,
      );

      if (!mounted) return;

      setState(() {
        _messages.add(_ChatMessage(text: reply, isUser: false));
      });
      _chatVersion.value++;
      await _scrollToBottom();
    } catch (error, stackTrace) {
      debugPrint('AiTradeX AI error: $error');
      debugPrintStack(stackTrace: stackTrace);

      if (!mounted) return;

      setState(() {
        _messages.add(
          _ChatMessage(
            text: _friendlyErrorMessage(error),
            isUser: false,
            isError: true,
          ),
        );
      });
      _chatVersion.value++;
      await _scrollToBottom();
    } finally {
      if (!mounted) return;
      setState(() => _isLoading = false);
      _chatVersion.value++;
    }
  }

  List<Map<String, String>> _buildHistory() {
    return _messages
        .where((item) => !item.isError && item.text.trim().isNotEmpty)
        .map(
          (item) => <String, String>{
        'role': item.isUser ? 'user' : 'assistant',
        'content': item.text.trim(),
      },
    )
        .toList();
  }

  Future<String> _requestAiResponse({
    required String message,
    required List<Map<String, String>> history,
  }) async {
    final User? firebaseUser = FirebaseAuth.instance.currentUser;

    if (firebaseUser == null) {
      throw const _AiException(
        'Please sign in again before using AiTradeX AI.',
      );
    }

    final String? idToken = await firebaseUser.getIdToken(true);

    if (idToken == null || idToken.trim().isEmpty) {
      throw const _AiException(
        'Your Firebase authentication token is unavailable. Please sign in again.',
      );
    }

    final Uri uri = Uri.parse('$_apiBaseUrl/ai/chat');
    late final http.Response response;

    try {
      response = await http
          .post(
        uri,
        headers: <String, String>{
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': 'Bearer ${idToken.trim()}',
        },
        body: jsonEncode(<String, dynamic>{
          'message': message.trim(),
          'history': history,
        }),
      )
          .timeout(const Duration(seconds: 60));
    } on http.ClientException catch (error) {
      throw _AiException(
        'Unable to connect to the AiTradeX server. ${error.message}',
      );
    } on Exception catch (error) {
      if (error.toString().toLowerCase().contains('timeout')) {
        throw const _AiException(
          'The AI service took too long to respond. Please try again.',
        );
      }
      rethrow;
    }

    final Map<String, dynamic> data = _decodeResponse(response.body);

    if (response.statusCode == 401) {
      throw const _AiException(
        'Your session has expired. Please sign in again.',
      );
    }

    if (response.statusCode == 429) {
      throw _AiException(
        _serverMessage(
          data,
          fallback:
          'AiTradeX AI is temporarily rate limited. Please try again shortly.',
        ),
      );
    }

    if (response.statusCode >= 500) {
      throw _AiException(
        _serverMessage(
          data,
          fallback:
          'AiTradeX AI is temporarily unavailable. Please try again shortly.',
        ),
      );
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw _AiException(
        _serverMessage(
          data,
          fallback: 'AiTradeX AI request failed (${response.statusCode}).',
        ),
      );
    }

    if (data['success'] != true) {
      throw _AiException(
        _serverMessage(
          data,
          fallback: 'AiTradeX AI could not generate a response.',
        ),
      );
    }

    final String? reply = _extractReply(data);

    if (reply == null || reply.trim().isEmpty) {
      throw const _AiException(
        'AiTradeX AI returned an empty response.',
      );
    }

    return reply.trim();
  }

  Map<String, dynamic> _decodeResponse(String body) {
    if (body.trim().isEmpty) {
      throw const _AiException(
        'The AiTradeX server returned an empty response.',
      );
    }

    try {
      final dynamic decoded = jsonDecode(body);
      if (decoded is Map<String, dynamic>) return decoded;
      throw const _AiException(
        'The AiTradeX server returned an invalid response.',
      );
    } on _AiException {
      rethrow;
    } on FormatException {
      throw const _AiException(
        'The AiTradeX server returned invalid JSON.',
      );
    }
  }

  String? _extractReply(Map<String, dynamic> data) {
    final dynamic rawMessage = data['message'];

    if (rawMessage is String && rawMessage.trim().isNotEmpty) {
      return rawMessage.trim();
    }

    if (rawMessage is Map<String, dynamic>) {
      final dynamic nested =
          rawMessage['message'] ?? rawMessage['reply'] ?? rawMessage['content'];
      if (nested is String && nested.trim().isNotEmpty) {
        return nested.trim();
      }
    }

    final dynamic reply = data['reply'];
    if (reply is String && reply.trim().isNotEmpty) return reply.trim();

    final dynamic response = data['response'];
    if (response is String && response.trim().isNotEmpty) {
      return response.trim();
    }

    return null;
  }

  String _serverMessage(
      Map<String, dynamic> data, {
        required String fallback,
      }) {
    final dynamic message = data['message'];
    if (message is String && message.trim().isNotEmpty) {
      return message.trim();
    }
    return fallback;
  }

  String _friendlyErrorMessage(Object error) {
    if (error is _AiException) return error.message;

    final String raw = error.toString().toLowerCase();
    if (raw.contains('network')) {
      return 'Network connection failed. Please check your internet connection and try again.';
    }
    if (raw.contains('timeout')) {
      return 'The AI service took too long to respond. Please try again.';
    }
    return 'Something went wrong while contacting AiTradeX AI. Please try again.';
  }

  void _openChatScreen() {
    if (!mounted) return;
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => _AiChatScreen(
          messages: _messages,
          controller: _messageController,
          scrollController: _scrollController,
          isLoading: _isLoading,
          version: _chatVersion,
          onSend: _sendMessage,
          onClear: _clearConversation,
        ),
      ),
    );
  }

  Future<void> _clearConversation() async {
    if (_isLoading) return;

    setState(() {
      _messages
        ..clear()
        ..add(
          const _ChatMessage(
            text: 'Conversation cleared. What would you like to explore?',
            isUser: false,
          ),
        );
    });

    await _scrollToBottom();
  }

  Future<void> _scrollToBottom() async {
    await Future<void>.delayed(const Duration(milliseconds: 80));
    if (!mounted || !_scrollController.hasClients) return;

    await _scrollController.animateTo(
      _scrollController.position.maxScrollExtent,
      duration: const Duration(milliseconds: 280),
      curve: Curves.easeOutCubic,
    );
  }

  // Opens the stock-report questionnaire with safe initial values.
  Future<void> _openStockAiReportQuestion() async {
    if (!mounted) return;

    FocusManager.instance.primaryFocus?.unfocus();

    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => const StockAiReportQuestionsScreen(
          company: 'NSE Stock',
          symbol: 'NSE',
          currentPrice: 0.0,
        ),
      ),
    );

    // The questionnaire may have created a new report and charged Coins.
    // Refresh both sections when the user returns to this screen.
    await _loadSavedReports();
    await _loadCoinBalance();
  }

  void _showExploreComingSoon() {
    if (!mounted) return;

    FocusManager.instance.primaryFocus?.unfocus();

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(
            'Explore is coming soon.',
            style: GoogleFonts.poppins(
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
          behavior: SnackBarBehavior.floating,
          duration: const Duration(seconds: 2),
        ),
      );
  }

  //noinspection SpellCheckingInspection
  void _askStock(String symbol) {
    final String prompt =
        'Give me a detailed report on $symbol. Explain the business, recent market trend, key risks, what I should check before investing, and possible scenarios. Do not guarantee returns.';
    _sendMessage(prompt);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _background,
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: <Widget>[
            SliverToBoxAdapter(child: _buildTopBar()),
            SliverToBoxAdapter(child: _buildHero()),
            SliverToBoxAdapter(child: _buildSearch()),
            SliverToBoxAdapter(child: _buildQuickActions()),
            SliverToBoxAdapter(child: _buildReportTabs()),
            SliverToBoxAdapter(child: _buildMyReports()),
            SliverToBoxAdapter(child: _buildMostAsked()),
            SliverToBoxAdapter(child: _buildPotentialStocks()),
            const SliverToBoxAdapter(child: SizedBox(height: 36)),
          ],
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
      child: Row(
        children: <Widget>[
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: _primary.withValues(alpha: .10),
              shape: BoxShape.circle,
              border: Border.all(color: _primary.withValues(alpha: .28)),
            ),
            child: Icon(Icons.auto_awesome_rounded, color: _primary, size: 21),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'AiTradeX AI',
                  style: GoogleFonts.poppins(
                    color: _onSurface,
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  'Your intelligent market assistant',
                  style: GoogleFonts.poppins(color: _muted, fontSize: 9.5),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
            decoration: BoxDecoration(
              color: _surface,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: _orange.withValues(alpha: .60)),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: _orange.withValues(alpha: .08),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                const Icon(Icons.monetization_on_rounded, color: _orange, size: 16),
                const SizedBox(width: 6),
                Text(
                  _isCoinLoading ? '...' : _coinBalance.toString(),
                  style: GoogleFonts.poppins(
                    color: _onSurface,
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(width: 3),
                Text(
                  'coins',
                  style: GoogleFonts.poppins(color: _muted, fontSize: 8.5),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHero() {
    final bool dark = _theme.brightness == Brightness.dark;
    final Color heroStart = dark ? _primary.withValues(alpha: .18) : _primary.withValues(alpha: .10);
    final Color heroEnd = dark ? _pink.withValues(alpha: .08) : _pink.withValues(alpha: .04);

    return Container(
      height: 214,
      margin: const EdgeInsets.fromLTRB(16, 10, 16, 12),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[_surface, heroStart, heroEnd],
        ),
        border: Border.all(color: _primary.withValues(alpha: .16)),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: _primary.withValues(alpha: dark ? .08 : .05),
            blurRadius: 24,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Stack(
        children: <Widget>[
          Positioned(left: -45, top: -65, child: _glowOrb(160, _pink.withValues(alpha: dark ? .16 : .08))),
          Positioned(right: -50, bottom: -75, child: _glowOrb(190, _primary.withValues(alpha: dark ? .14 : .08))),
          Positioned.fill(child: CustomPaint(painter: _HeroGridPainter(isDark: dark))),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Container(
                  width: 78,
                  height: 78,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(colors: <Color>[_primary, _pink]),
                    boxShadow: <BoxShadow>[
                      BoxShadow(color: _primary.withValues(alpha: .22), blurRadius: 30),
                    ],
                  ),
                  child: const Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 38),
                ),
                const SizedBox(height: 13),
                Text(
                  "Hi, I'm AiTradeX!",
                  style: GoogleFonts.poppins(color: _onSurface, fontSize: 20, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 2),
                Text(
                  'How can I help you today?',
                  style: GoogleFonts.poppins(color: _muted, fontSize: 13, fontWeight: FontWeight.w500),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _glowOrb(double size, Color color) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
      ),
    );
  }

  Widget _buildSearch() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      child: GestureDetector(
        onTap: _openChatScreen,
        child: Container(
          height: 48,
          padding: const EdgeInsets.only(left: 15, right: 6),
          decoration: BoxDecoration(
            color: _surface,
            borderRadius: BorderRadius.circular(15),
            border: Border.all(color: _primary.withValues(alpha: .45)),
          ),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Text(
                  'Ask about investments',
                  style: GoogleFonts.poppins(
                    color: _muted,
                    fontSize: 10.5,
                  ),
                ),
              ),
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: _green,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.send_rounded,
                  color: Colors.black,
                  size: 18,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildQuickActions() {
    final List<_ActionCard> actions = <_ActionCard>[
      _ActionCard(
        icon: Icons.pie_chart_rounded,
        title: 'Get a report on\nany NSE stock',
        action: 'Ask AiTradeX',
        onTap: () => _openStockAiReportQuestion(),
      ),
      _ActionCard(
        icon: Icons.chat_bubble_rounded,
        title: 'Ask about\nMarket',
        action: 'Chat now',
        onTap: _openChatScreen,
      ),
      _ActionCard(
        icon: Icons.search_rounded,
        title: 'Get insights on\nany stock',
        action: 'Explore',
        onTap: _showExploreComingSoon,
      ),
    ];

    return SizedBox(
      height: 145,
      child: ListView.separated(
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
        scrollDirection: Axis.horizontal,
        itemCount: actions.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, int index) => actions[index],
      ),
    );
  }

  Widget _buildReportTabs() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 2, 14, 16),
      child: Row(
        children: <Widget>[
          Expanded(
            child: _gradientTab(
              title: 'Stock reports',
              selected: !_showPortfolioReports,
              onTap: () => setState(() => _showPortfolioReports = false),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: _gradientTab(
              title: 'Portfolio reports',
              selected: _showPortfolioReports,
              onTap: () => setState(() => _showPortfolioReports = true),
            ),
          ),
        ],
      ),
    );
  }

  Widget _gradientTab({
    required String title,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        height: 34,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          gradient: selected
              ? const LinearGradient(colors: <Color>[_pink, _orange])
              : null,
          color: selected ? null : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          title,
          style: GoogleFonts.poppins(
            color: selected ? Colors.white : _muted,
            fontSize: 10,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }

  Widget _buildMyReports() {
    if (_showPortfolioReports) {
      return _section(
        title: 'Portfolio reports',
        child: _emptyReportState('No portfolio reports yet.'),
      );
    }

    return _section(
      title: 'My reports',
      trailing: _reports.isEmpty ? null : '${_reports.length} reports',
      child: _reports.isEmpty
          ? _emptyReportState('Your completed stock reports will appear here.')
          : Column(
        children: _reports.map(_reportTile).toList(),
      ),
    );
  }

  Widget _section({
    required String title,
    required Widget child,
    String? trailing,
  }) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(
                child: Text(
                  title,
                  style: GoogleFonts.poppins(
                    color: _onSurface,
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              if (trailing != null)
                Text(
                  trailing,
                  style: GoogleFonts.poppins(
                    color: _primary,
                    fontSize: 9.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }

  Widget _reportTile(_ReportItem item) {
    return InkWell(
      onTap: () => _openSavedReport(item),
      borderRadius: BorderRadius.circular(13),
      child: Container(
        height: 68,
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: _surface,
          borderRadius: BorderRadius.circular(13),
          border: Border.all(color: _onSurface.withValues(alpha: .08)),
        ),
        child: Row(
          children: <Widget>[
            Container(
              width: 36,
              height: 36,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: _primary.withValues(alpha: .10),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                item.logo,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.poppins(
                  color: _primary,
                  fontSize: 8,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    item.symbol,
                    style: GoogleFonts.poppins(
                      color: _onSurface,
                      fontSize: 10.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    item.date,
                    style: GoogleFonts.poppins(
                      color: _muted,
                      fontSize: 8,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                color: _primary.withValues(alpha: .10),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.chevron_right_rounded,
                color: _primary,
                size: 18,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _emptyReportState(String text) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: _surface,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: GoogleFonts.poppins(color: _muted, fontSize: 10),
      ),
    );
  }

  Widget _buildMostAsked() {
    return _section(
      title: 'Most asked reports',
      child: SizedBox(
        height: 125,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          itemCount: _mostAsked.length,
          separatorBuilder: (_, __) => const SizedBox(width: 8),
          itemBuilder: (_, int index) {
            final _AskedReport item = _mostAsked[index];
            return Container(
              width: 112,
              padding: const EdgeInsets.fromLTRB(10, 9, 10, 8),
              decoration: BoxDecoration(
                color: _surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _onSurface.withValues(alpha: .08)),
              ),
              child: Column(
                children: <Widget>[
                  Container(
                    width: 38,
                    height: 38,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      item.logo,
                      style: GoogleFonts.poppins(
                        color: Colors.black,
                        fontSize: 8,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    item.symbol,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.poppins(
                      color: _onSurface,
                      fontSize: 9.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    item.requests,
                    style: GoogleFonts.poppins(
                      color: _muted,
                      fontSize: 8,
                    ),
                  ),
                  Text(
                    item.period,
                    style: GoogleFonts.poppins(
                      color: _muted.withValues(alpha: .55),
                      fontSize: 7.5,
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildPotentialStocks() {
    return _section(
      title: 'Potentially buy rated stocks by AiTradeX',
      child: SizedBox(
        height: 184,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          itemCount: _potentialStocks.length,
          separatorBuilder: (_, __) => const SizedBox(width: 8),
          itemBuilder: (_, int index) {
            final _PotentialStock stock = _potentialStocks[index];
            final bool dark = _theme.brightness == Brightness.dark;
            final Color cardStart = dark
                ? const Color(0xFF123C2C)
                : _surface;
            final Color cardEnd = dark
                ? const Color(0xFF0B1C15)
                : _primary.withValues(alpha: .06);

            return Container(
              width: 145,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(17),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: <Color>[cardStart, cardEnd],
                ),
                border: Border.all(color: _green.withValues(alpha: .18)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: .35),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.lock_rounded,
                      color: _orange,
                      size: 15,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    'Tap to reveal',
                    style: GoogleFonts.poppins(
                      color: _onSurface.withValues(alpha: .72),
                      fontSize: 9,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    stock.upside,
                    style: GoogleFonts.poppins(
                      color: _green,
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  Text(
                    stock.label,
                    style: GoogleFonts.poppins(
                      color: _muted,
                      fontSize: 7.5,
                    ),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    height: 30,
                    child: ElevatedButton(
                      onPressed: () => _askStock(stock.symbol),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _primary,
                        foregroundColor: _theme.colorScheme.onPrimary,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(9),
                        ),
                        padding: EdgeInsets.zero,
                      ),
                      child: Text(
                        'Get report',
                        style: GoogleFonts.poppins(
                          fontSize: 9,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

}

class _ActionCard extends StatelessWidget {
  const _ActionCard({
    required this.icon,
    required this.title,
    required this.action,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String action;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final Color surface = theme.colorScheme.surface;
    final Color onSurface = theme.colorScheme.onSurface;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 110,
        padding: const EdgeInsets.fromLTRB(10, 10, 9, 9),
        decoration: BoxDecoration(
          color: surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: onSurface.withValues(alpha: .08)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary.withValues(alpha: .10),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: Theme.of(context).colorScheme.primary, size: 17),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: Text(
                title,
                style: GoogleFonts.poppins(
                  color: onSurface,
                  fontSize: 9.5,
                  height: 1.35,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            Text(
              '$action  ›',
              style: GoogleFonts.poppins(
                color: const Color(0xFFFFB52E),
                fontSize: 8.5,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AiChatScreen extends StatefulWidget {
  const _AiChatScreen({
    required this.messages,
    required this.controller,
    required this.scrollController,
    required this.isLoading,
    required this.version,
    required this.onSend,
    required this.onClear,
  });

  final List<_ChatMessage> messages;
  final TextEditingController controller;
  final ScrollController scrollController;
  final bool isLoading;
  final ValueNotifier<int> version;
  final Future<void> Function([String? predefinedMessage]) onSend;
  final Future<void> Function() onClear;

  @override
  State<_AiChatScreen> createState() => _AiChatScreenState();
}

class _AiChatScreenState extends State<_AiChatScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        foregroundColor: Theme.of(context).colorScheme.onSurface,
        elevation: 0,
        title: Row(
          children: <Widget>[
            Container(
              width: 36,
              height: 36,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(colors: <Color>[
                  _AiTradeXChatbotScreenState._pink,
                  _AiTradeXChatbotScreenState._green,
                ]),
              ),
              child: const Icon(Icons.auto_awesome_rounded,
                  color: Colors.white, size: 19),
            ),
            const SizedBox(width: 10),
            Text(
              'AiTradeX AI',
              style: GoogleFonts.poppins(
                fontSize: 16,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
        actions: <Widget>[
          IconButton(
            onPressed: widget.isLoading ? null : widget.onClear,
            icon: const Icon(Icons.delete_outline_rounded),
          ),
        ],
      ),
      body: ValueListenableBuilder<int>(
        valueListenable: widget.version,
        builder: (BuildContext context, int _, Widget? child) {
          return Column(
            children: <Widget>[
              Expanded(
                child: ListView.builder(
                  controller: widget.scrollController,
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 18),
                  itemCount: widget.messages.length + (widget.isLoading ? 1 : 0),
                  itemBuilder: (_, int index) {
                    if (widget.isLoading && index == widget.messages.length) {
                      return const _TypingBubble();
                    }
                    return _MessageBubble(
                      message: widget.messages[index],
                      primary: _AiTradeXChatbotScreenState._green,
                    );
                  },
                ),
              ),
              _ChatComposer(
                controller: widget.controller,
                isLoading: widget.isLoading,
                onSend: widget.onSend,
              ),
            ],
          );
        },
      ),
    );
  }
}

class _ChatComposer extends StatelessWidget {
  const _ChatComposer({
    required this.controller,
    required this.isLoading,
    required this.onSend,
  });

  final TextEditingController controller;
  final bool isLoading;
  final Future<void> Function([String? predefinedMessage]) onSend;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(12, 9, 12, 12),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          border: Border(
            top: BorderSide(
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .06),
            ),
          ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            Expanded(
              child: Container(
                constraints: const BoxConstraints(maxHeight: 110),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .10),
                  ),
                ),
                child: TextField(
                  controller: controller,
                  minLines: 1,
                  maxLines: 4,
                  style: GoogleFonts.poppins(
                    color: Theme.of(context).colorScheme.onSurface,
                    fontSize: 12,
                  ),
                  decoration: InputDecoration(
                    hintText: 'Ask about stocks, markets...',
                    hintStyle: GoogleFonts.poppins(
                      color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .45),
                      fontSize: 11,
                    ),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 15,
                      vertical: 13,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: isLoading ? null : () => onSend(),
              child: Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: isLoading
                      ? _AiTradeXChatbotScreenState._green.withValues(alpha: .45)
                      : _AiTradeXChatbotScreenState._green,
                  borderRadius: BorderRadius.circular(17),
                ),
                child: isLoading
                    ? const Padding(
                  padding: EdgeInsets.all(15),
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.black,
                  ),
                )
                    : const Icon(
                  Icons.arrow_upward_rounded,
                  color: Colors.black,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  const _MessageBubble({required this.message, required this.primary});

  final _ChatMessage message;
  final Color primary;

  @override
  Widget build(BuildContext context) {
    if (message.isUser) {
      return Align(
        alignment: Alignment.centerRight,
        child: Container(
          constraints: const BoxConstraints(maxWidth: 330),
          margin: const EdgeInsets.only(left: 45, bottom: 10),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
          decoration: const BoxDecoration(
            color: _AiTradeXChatbotScreenState._green,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(18),
              topRight: Radius.circular(18),
              bottomLeft: Radius.circular(18),
              bottomRight: Radius.circular(5),
            ),
          ),
          child: Text(
            message.text,
            style: GoogleFonts.poppins(
              color: Colors.black,
              fontSize: 12,
              height: 1.45,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      );
    }

    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 350),
        margin: const EdgeInsets.only(right: 25, bottom: 12),
        padding: const EdgeInsets.fromLTRB(12, 12, 14, 13),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(5),
            topRight: Radius.circular(18),
            bottomLeft: Radius.circular(18),
            bottomRight: Radius.circular(18),
          ),
          border: Border.all(
            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .08),
          ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                color: primary.withValues(alpha: .12),
                borderRadius: BorderRadius.circular(9),
              ),
              child: Icon(
                message.isError
                    ? Icons.error_outline_rounded
                    : Icons.auto_awesome_rounded,
                size: 15,
                color: message.isError ? Colors.redAccent : primary,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                message.text,
                style: GoogleFonts.poppins(
                  color: message.isError ? Colors.redAccent : Theme.of(context).colorScheme.onSurface,
                  fontSize: 12,
                  height: 1.5,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TypingBubble extends StatefulWidget {
  const _TypingBubble();

  @override
  State<_TypingBubble> createState() => _TypingBubbleState();
}

class _TypingBubbleState extends State<_TypingBubble>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 82,
      height: 46,
      margin: const EdgeInsets.only(right: 30, bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(18),
      ),
      child: AnimatedBuilder(
        animation: _controller,
        builder: (_, __) {
          return Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: List<Widget>.generate(3, (int index) {
              final double value = (_controller.value + index / 3) % 1.0;
              final double scale =
                  0.65 + (math.sin(value * 2 * math.pi) + 1) * 0.18;
              return Transform.scale(
                scale: scale,
                child: Container(
                  width: 7,
                  height: 7,
                  decoration: BoxDecoration(
                    color: _AiTradeXChatbotScreenState._green.withValues(
                      alpha: .45 + (scale - .65) * 1.2,
                    ),
                    shape: BoxShape.circle,
                  ),
                ),
              );
            }),
          );
        },
      ),
    );
  }
}

class _HeroGridPainter extends CustomPainter {
  const _HeroGridPainter({required this.isDark});

  final bool isDark;
  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..color = (isDark ? Colors.white : Colors.black).withValues(alpha: .035)
      ..strokeWidth = 1;

    const double gap = 42;
    for (double x = 0; x <= size.width; x += gap) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y <= size.height; y += gap) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _ChatMessage {
  const _ChatMessage({
    required this.text,
    required this.isUser,
    this.isError = false,
  });

  final String text;
  final bool isUser;
  final bool isError;
}

class _AiException implements Exception {
  const _AiException(this.message);

  final String message;

  @override
  String toString() => message;
}

class _ReportItem {
  const _ReportItem(
      this.symbol,
      this.date,
      this.logo, {
        this.company = '',
        this.report = '',
        this.remainingCoins = 0,
      });

  final String symbol;
  final String date;
  final String logo;
  final String company;
  final String report;
  final int remainingCoins;

  Map<String, dynamic> toJson() => <String, dynamic>{
    'symbol': symbol,
    'date': date,
    'logo': logo,
    'company': company,
    'report': report,
    'remainingCoins': remainingCoins,
  };

  factory _ReportItem.fromJson(Map<String, dynamic> json) {
    final dynamic rawBalance = json['remainingCoins'];
    final int balance = rawBalance is num
        ? rawBalance.toInt()
        : int.tryParse(rawBalance?.toString() ?? '') ?? 0;
    return _ReportItem(
      json['symbol']?.toString() ?? '',
      json['date']?.toString() ?? '',
      json['logo']?.toString() ?? '',
      company: json['company']?.toString() ?? '',
      report: json['report']?.toString() ?? '',
      remainingCoins: balance,
    );
  }
}

class _SavedReportScreen extends StatelessWidget {
  const _SavedReportScreen({required this.report});

  final _ReportItem report;

  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;
    final String title = report.symbol.trim().isEmpty
        ? 'AiTradeX Report'
        : '${report.symbol} AI Report';

    return Scaffold(
      backgroundColor: colors.surface,
      appBar: AppBar(
        title: Text(
          title,
          style: GoogleFonts.poppins(
            fontSize: 17,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 30),
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: <Color>[
                  colors.primary,
                  colors.primary.withValues(alpha: .72),
                ],
              ),
              borderRadius: BorderRadius.circular(22),
            ),
            child: Row(
              children: <Widget>[
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: colors.onPrimary.withValues(alpha: .14),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.auto_awesome_rounded,
                    color: colors.onPrimary,
                  ),
                ),
                const SizedBox(width: 13),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        report.company.isEmpty ? report.symbol : report.company,
                        style: GoogleFonts.poppins(
                          color: colors.onPrimary,
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        '${report.symbol} • AiTradeX AI report',
                        style: GoogleFonts.poppins(
                          color: colors.onPrimary.withValues(alpha: .78),
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: colors.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: colors.outlineVariant),
            ),
            child: Text(
              report.report,
              style: GoogleFonts.poppins(
                color: colors.onSurface,
                fontSize: 12,
                height: 1.65,
              ),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: <Widget>[
              Icon(Icons.account_balance_wallet_rounded,
                  color: colors.primary, size: 18),
              const SizedBox(width: 8),
              Text(
                '${report.remainingCoins} Coins remaining after unlock',
                style: GoogleFonts.poppins(
                  color: colors.onSurface,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            'AI-generated information is for educational purposes only and does not guarantee investment returns.',
            textAlign: TextAlign.center,
            style: GoogleFonts.poppins(
              color: colors.onSurfaceVariant,
              fontSize: 8.5,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }
}


class _AskedReport {
  const _AskedReport(this.symbol, this.requests, this.period, this.logo);

  final String symbol;
  final String requests;
  final String period;
  final String logo;
}

class _PotentialStock {
  const _PotentialStock(this.symbol, this.upside, this.label);

  final String symbol;
  final String upside;
  final String label;
}
