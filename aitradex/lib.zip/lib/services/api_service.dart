import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class ApiService {
  ApiService._();

  // ============================================================
  // BASE URL
  // ============================================================

  /// Production Render API.
  static const String baseUrl =
      'https://aitradex-api.onrender.com';

  // ============================================================
  // FIREBASE AUTH
  // ============================================================

  static FirebaseAuth get _firebaseAuth =>
      FirebaseAuth.instance;

  // ============================================================
  // GET FIREBASE ID TOKEN
  // ============================================================

  static Future<String?> _getFirebaseIdToken() async {
    try {
      final User? user =
          _firebaseAuth.currentUser;

      if (user == null) {
        debugPrint(
          'API AUTH: No Firebase user is currently signed in.',
        );

        return null;
      }

      final String? token =
      await user.getIdToken();

      if (token == null || token.trim().isEmpty) {
        debugPrint(
          'API AUTH: Firebase ID token is empty.',
        );

        return null;
      }

      return token.trim();
    } catch (e, stackTrace) {
      debugPrint(
        '========================================',
      );
      debugPrint(
        'FIREBASE ID TOKEN ERROR',
      );
      debugPrint(
        '========================================',
      );
      debugPrint(
        'Error: $e',
      );
      debugPrint(
        'StackTrace: $stackTrace',
      );
      debugPrint(
        '========================================',
      );

      return null;
    }
  }

  // ============================================================
  // COMMON HEADERS
  // ============================================================

  static Future<Map<String, String>>
  _authHeaders() async {
    final Map<String, String> headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    final String? token =
    await _getFirebaseIdToken();

    if (token != null && token.isNotEmpty) {
      headers['Authorization'] =
      'Bearer $token';
    }

    return headers;
  }

  // ============================================================
  // DELETE ACCOUNT
  // ============================================================

  static Future<bool> deleteAccount() async {
    try {
      final User? user =
          _firebaseAuth.currentUser;

      // --------------------------------------------------------
      // FIREBASE USER CHECK
      // --------------------------------------------------------

      if (user == null) {
        debugPrint(
          'DELETE ACCOUNT: NO FIREBASE USER FOUND.',
        );

        return false;
      }

      // --------------------------------------------------------
      // FIREBASE TOKEN CHECK
      // --------------------------------------------------------

      final String? token =
      await _getFirebaseIdToken();

      if (token == null || token.isEmpty) {
        debugPrint(
          'DELETE ACCOUNT: FIREBASE ID TOKEN NOT FOUND.',
        );

        return false;
      }

      // --------------------------------------------------------
      // API URL
      // --------------------------------------------------------

      final Uri uri = Uri.parse(
        '$baseUrl/api/users/delete',
      );

      debugPrint('');
      debugPrint(
        '========================================',
      );
      debugPrint(
        'DELETE ACCOUNT REQUEST',
      );
      debugPrint(
        '========================================',
      );
      debugPrint(
        'URL: $uri',
      );
      debugPrint(
        'Firebase UID: ${user.uid}',
      );
      debugPrint(
        'Token: ********',
      );
      debugPrint(
        '========================================',
      );

      // --------------------------------------------------------
      // API REQUEST
      // --------------------------------------------------------

      final http.Response response =
      await http.delete(
        uri,
        headers: await _authHeaders(),
      );

      // --------------------------------------------------------
      // RESPONSE LOG
      // --------------------------------------------------------

      debugPrint('');
      debugPrint(
        '========================================',
      );
      debugPrint(
        'DELETE ACCOUNT RESPONSE',
      );
      debugPrint(
        '========================================',
      );
      debugPrint(
        'STATUS: ${response.statusCode}',
      );
      debugPrint(
        'BODY: ${response.body}',
      );
      debugPrint(
        '========================================',
      );

      // --------------------------------------------------------
      // SUCCESS
      // --------------------------------------------------------

      if (response.statusCode == 200) {
        try {
          final dynamic decoded =
          jsonDecode(response.body);

          if (decoded is Map<String, dynamic>) {
            return decoded['success'] == true;
          }
        } catch (e) {
          debugPrint(
            'DELETE ACCOUNT JSON ERROR: $e',
          );
        }

        return true;
      }

      // --------------------------------------------------------
      // UNAUTHORIZED
      // --------------------------------------------------------

      if (response.statusCode == 401) {
        debugPrint(
          'DELETE ACCOUNT: UNAUTHORIZED.',
        );

        return false;
      }

      // --------------------------------------------------------
      // USER NOT FOUND
      // --------------------------------------------------------

      if (response.statusCode == 404) {
        debugPrint(
          'DELETE ACCOUNT: USER NOT FOUND.',
        );

        return false;
      }

      // --------------------------------------------------------
      // SERVER ERROR
      // --------------------------------------------------------

      debugPrint(
        'DELETE ACCOUNT FAILED: '
            '${response.statusCode}',
      );

      return false;
    } catch (e, stackTrace) {
      debugPrint('');
      debugPrint(
        '========================================',
      );
      debugPrint(
        'DELETE ACCOUNT EXCEPTION',
      );
      debugPrint(
        '========================================',
      );
      debugPrint(
        'Error: $e',
      );
      debugPrint(
        'StackTrace: $stackTrace',
      );
      debugPrint(
        '========================================',
      );

      return false;
    }
  }
}