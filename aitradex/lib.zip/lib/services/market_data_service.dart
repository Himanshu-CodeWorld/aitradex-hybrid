
import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

/// Normalized quote returned by the AiTradeX backend.
///
/// Flutter talks only to the AiTradeX backend. Upstox client secrets and
/// OAuth access tokens must remain on the Node.js/Render server.
class MarketQuote {
  final String instrumentKey;
  final String symbol;
  final double lastPrice;
  final double changePercent;
  final double? previousClose;
  final int? volume;

  const MarketQuote({
    required this.instrumentKey,
    required this.symbol,
    required this.lastPrice,
    required this.changePercent,
    this.previousClose,
    this.volume,
  });

  factory MarketQuote.fromJson(
      String instrumentKey,
      Map<String, dynamic> json,
      ) {
    final ohlc = _asMap(
      json['ohlc'] ?? json['OHLC'],
    );

    final lastPrice = _toDouble(
      _firstValue(json, const [
        'last_price',
        'lastPrice',
        'ltp',
        'last_traded_price',
        'lastTradedPrice',
        'close',
      ]),
    );

    final previousClose = _nullableDouble(
      _firstValue(json, const [
        'previous_close',
        'previousClose',
        'prev_close',
        'prevClose',
        'previous_close_price',
      ]) ??
          _firstValue(ohlc, const [
            'close',
            'previous_close',
            'previousClose',
          ]),
    );

    var changePercent = _toDouble(
      _firstValue(json, const [
        'change_percent',
        'changePercent',
        'percentage_change',
        'percentageChange',
        'percent_change',
        'change_percentage',
      ]),
    );

    // Calculate the percentage when the backend only provides LTP and
    // previous close.
    if (changePercent == 0 &&
        previousClose != null &&
        previousClose != 0 &&
        lastPrice != 0) {
      changePercent =
          ((lastPrice - previousClose) / previousClose) * 100;
    }

    return MarketQuote(
      instrumentKey: instrumentKey,
      symbol: _readString(
        _firstValue(json, const [
          'symbol',
          'trading_symbol',
          'tradingSymbol',
          'display_name',
          'displayName',
          'name',
        ]) ??
            '',
      ),
      lastPrice: lastPrice,
      changePercent: changePercent,
      previousClose: previousClose,
      volume: _nullableInt(
        _firstValue(json, const [
          'volume',
          'total_volume',
          'totalVolume',
          'volume_traded',
          'volumeTraded',
        ]),
      ),
    );
  }

  MarketQuote copyWith({
    String? symbol,
    double? lastPrice,
    double? changePercent,
    double? previousClose,
    int? volume,
  }) {
    return MarketQuote(
      instrumentKey: instrumentKey,
      symbol: symbol ?? this.symbol,
      lastPrice: lastPrice ?? this.lastPrice,
      changePercent: changePercent ?? this.changePercent,
      previousClose: previousClose ?? this.previousClose,
      volume: volume ?? this.volume,
    );
  }

  static dynamic _firstValue(
      Map<String, dynamic> map,
      List<String> keys,
      ) {
    for (final key in keys) {
      if (map.containsKey(key) && map[key] != null) {
        return map[key];
      }
    }
    return null;
  }

  static Map<String, dynamic> _asMap(dynamic value) {
    if (value is Map<String, dynamic>) {
      return value;
    }

    if (value is Map) {
      return Map<String, dynamic>.from(value);
    }

    return <String, dynamic>{};
  }

  static String _readString(dynamic value) {
    if (value == null) return '';
    return value.toString().trim();
  }

  static double _toDouble(dynamic value) {
    if (value is num) return value.toDouble();

    final raw = value?.toString().trim() ?? '';
    if (raw.isEmpty) return 0;

    return double.tryParse(raw.replaceAll(',', '')) ?? 0;
  }

  static double? _nullableDouble(dynamic value) {
    if (value == null) return null;

    if (value is num) {
      return value.toDouble();
    }

    final raw = value.toString().trim().replaceAll(',', '');
    if (raw.isEmpty) return null;

    return double.tryParse(raw);
  }

  static int? _nullableInt(dynamic value) {
    if (value == null) return null;

    if (value is int) return value;

    if (value is num) return value.toInt();

    final raw = value.toString().trim().replaceAll(',', '');
    if (raw.isEmpty) return null;

    return int.tryParse(raw) ??
        double.tryParse(raw)?.toInt();
  }
}

/// AiTradeX market-data API client.
///
/// Expected backend route:
/// GET /api/upstox/market-data?instrument_key=A,B,C
///
/// The backend is responsible for authenticating with Upstox and returning
/// safe market data. No Upstox secret/token is stored in this Flutter class.
class MarketDataService {
  MarketDataService._();

  static const String baseUrl = 'https://aitradex-api.onrender.com';
  static const String endpoint = '$baseUrl/api/upstox/market-data';

  static const Duration requestTimeout = Duration(seconds: 20);

  static Future<Map<String, MarketQuote>> fetchMarketData(
      List<String> instrumentKeys, {
        Duration timeout = requestTimeout,
      }) async {
    final keys = _normalizeKeys(instrumentKeys);

    if (keys.isEmpty) {
      return <String, MarketQuote>{};
    }

    final uri = Uri.parse(endpoint).replace(
      queryParameters: <String, String>{
        'instrument_key': keys.join(','),
      },
    );

    http.Response response;

    try {
      response = await http
          .get(
        uri,
        headers: const {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
      )
          .timeout(timeout);
    } on TimeoutException {
      throw const MarketDataException(
        'Market data request timed out. Please try again.',
      );
    } on http.ClientException catch (error) {
      throw MarketDataException(
        'Unable to connect to AiTradeX market API: ${error.message}',
      );
    } catch (error) {
      throw MarketDataException(
        'Unable to load market data: $error',
      );
    }

    final body = _decodeBody(response.body);

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw MarketDataException(
        _messageFromBody(
          body,
          fallback:
          'Market data request failed (${response.statusCode}).',
        ),
        statusCode: response.statusCode,
      );
    }

    if (_isExplicitFailure(body)) {
      throw MarketDataException(
        _messageFromBody(
          body,
          fallback: 'Market data is currently unavailable.',
        ),
        statusCode: response.statusCode,
      );
    }

    final quotes = <String, MarketQuote>{};

    // Common response shapes are intentionally supported:
    // { success: true, data: {...} }
    // { data: {...} }
    // { market_data: {...} }
    // { quotes: {...} }
    // { data: [...] }
    // {...direct instrument-key map...}
    _extractQuotes(body['data'], quotes);
    _extractQuotes(body['market_data'], quotes);
    _extractQuotes(body['marketData'], quotes);
    _extractQuotes(body['quotes'], quotes);
    _extractQuotes(body['results'], quotes);

    if (quotes.isEmpty) {
      _extractQuotes(body, quotes);
    }

    // Some APIs return only a single quote object without its instrument key.
    // We cannot safely associate that object with a requested key unless the
    // response itself contains the key, so it is deliberately not guessed.
    return _filterRequestedQuotes(quotes, keys);
  }

  static Map<String, MarketQuote> _filterRequestedQuotes(
    Map<String, MarketQuote> quotes,
    List<String> requestedKeys,
  ) {
    if (quotes.isEmpty || requestedKeys.isEmpty) {
      return <String, MarketQuote>{};
    }

    final requested = requestedKeys.toSet();
    final filtered = <String, MarketQuote>{};

    for (final entry in quotes.entries) {
      final key = entry.key.trim();

      if (key.isEmpty || !requested.contains(key)) {
        continue;
      }

      filtered[key] = entry.value;
    }

    return filtered;
  }

  /// Fetch one quote.
  static Future<MarketQuote?> fetchQuote(
      String instrumentKey, {
        Duration timeout = requestTimeout,
      }) async {
    final key = instrumentKey.trim();
    if (key.isEmpty) return null;

    final quotes = await fetchMarketData(
      <String>[key],
      timeout: timeout,
    );

    return quotes[key];
  }

  static List<String> _normalizeKeys(List<String> keys) {
    final result = <String>[];
    final seen = <String>{};

    for (final raw in keys) {
      final key = raw.trim();
      if (key.isEmpty || !seen.add(key)) continue;
      result.add(key);
    }

    return result;
  }

  static Map<String, dynamic> _decodeBody(String rawBody) {
    if (rawBody.trim().isEmpty) {
      throw const MarketDataException(
        'Market API returned an empty response.',
      );
    }

    try {
      final decoded = jsonDecode(rawBody);

      if (decoded is Map<String, dynamic>) {
        return decoded;
      }

      if (decoded is Map) {
        return Map<String, dynamic>.from(decoded);
      }

      throw const MarketDataException(
        'Market API returned an invalid JSON object.',
      );
    } on MarketDataException {
      rethrow;
    } on FormatException catch (error) {
      throw MarketDataException(
        'Invalid market-data JSON response: $error',
      );
    } catch (error) {
      throw MarketDataException(
        'Unable to read market-data response: $error',
      );
    }
  }

  static bool _isExplicitFailure(Map<String, dynamic> body) {
    final success = body['success'];

    if (success is bool && !success) {
      return true;
    }

    final ok = body['ok'];

    if (ok is bool && !ok) {
      return true;
    }

    final status = body['status']?.toString().toLowerCase();

    return status == 'error' || status == 'failed';
  }

  static String _messageFromBody(
      Map<String, dynamic> body, {
        required String fallback,
      }) {
    for (final key in const [
      'message',
      'error',
      'error_description',
      'detail',
    ]) {
      final value = body[key];

      if (value != null && value.toString().trim().isNotEmpty) {
        return value.toString().trim();
      }
    }

    final errorObject = body['errors'];

    if (errorObject is List && errorObject.isNotEmpty) {
      return errorObject.first.toString();
    }

    if (errorObject is Map) {
      final map = Map<String, dynamic>.from(errorObject);

      for (final key in const ['message', 'error', 'description']) {
        final value = map[key];

        if (value != null && value.toString().trim().isNotEmpty) {
          return value.toString().trim();
        }
      }
    }

    return fallback;
  }

  static void _extractQuotes(
      dynamic value,
      Map<String, MarketQuote> result,
      ) {
    if (value == null) return;

    if (value is List) {
      for (final item in value) {
        if (item is Map) {
          _extractSingleQuote(
            Map<String, dynamic>.from(item),
            result,
          );
        }
      }
      return;
    }

    if (value is! Map) return;

    final map = Map<String, dynamic>.from(value);

    // A single quote object:
    // {
    //   instrument_key: "NSE_EQ|...",
    //   last_price: 1421.70
    // }
    final explicitKey = _firstString(
      map,
      const [
        'instrument_key',
        'instrumentKey',
        'key',
      ],
    );

    if (explicitKey != null && _looksLikeQuote(map)) {
      final normalized = _unwrapQuote(map);

      result[explicitKey] = MarketQuote.fromJson(
        explicitKey,
        normalized,
      );
      return;
    }

    // Direct Upstox-style map:
    // {
    //   "NSE_EQ|INE002A01018": {
    //      "last_price": 1421.70,
    //      ...
    //   }
    // }
    for (final entry in map.entries) {
      final entryKey = entry.key.trim();
      if (entryKey.isEmpty) continue;

      final entryValue = entry.value;

      if (entryValue is Map) {
        final quoteMap = Map<String, dynamic>.from(
          entryValue,
        );

        final nestedKey = _firstString(
          quoteMap,
          const [
            'instrument_key',
            'instrumentKey',
            'key',
          ],
        );

        final key = nestedKey ?? entryKey;
        final normalized = _unwrapQuote(quoteMap);

        if (_looksLikeQuote(normalized)) {
          result[key] = MarketQuote.fromJson(
            key,
            normalized,
          );
        }
      }
    }
  }

  static void _extractSingleQuote(
      Map<String, dynamic> map,
      Map<String, MarketQuote> result,
      ) {
    final key = _firstString(
      map,
      const [
        'instrument_key',
        'instrumentKey',
        'key',
      ],
    );

    if (key == null) return;

    final normalized = _unwrapQuote(map);

    if (!_looksLikeQuote(normalized)) return;

    result[key] = MarketQuote.fromJson(
      key,
      normalized,
    );
  }

  static Map<String, dynamic> _unwrapQuote(
      Map<String, dynamic> value,
      ) {
    // Do not unwrap an `ltp` numeric value. Only unwrap nested maps.
    for (final key in const [
      'data',
      'quote',
      'result',
    ]) {
      final nested = value[key];

      if (nested is Map) {
        return Map<String, dynamic>.from(nested);
      }
    }

    return value;
  }

  static bool _looksLikeQuote(
      Map<String, dynamic> map,
      ) {
    return map.containsKey('last_price') ||
        map.containsKey('lastPrice') ||
        map.containsKey('ltp') ||
        map.containsKey('last_traded_price') ||
        map.containsKey('lastTradedPrice') ||
        map.containsKey('close');
  }

  static String? _firstString(
      Map<String, dynamic> map,
      List<String> keys,
      ) {
    for (final key in keys) {
      final value = map[key];

      if (value == null) continue;

      final text = value.toString().trim();

      if (text.isNotEmpty) {
        return text;
      }
    }

    return null;
  }

  /// Formats a market price in Indian rupees.
  static String formatPrice(
      double value, {
        bool compact = false,
      }) {
    if (!value.isFinite || value == 0) return '—';

    return '₹${_formatNumber(value, compact: compact)}';
  }

  /// Formats percentage change with a sign.
  static String formatPercent(double value) {
    if (!value.isFinite) return '—';

    if (value.abs() < 0.000001) {
      return '0.00%';
    }

    final sign = value > 0 ? '+' : '';

    return '$sign${value.toStringAsFixed(2)}%';
  }

  /// Formats an absolute rupee amount.
  static String formatAmount(double value) {
    if (!value.isFinite) return '—';

    final sign = value < 0 ? '-' : '';
    final absolute = value.abs();

    return '$sign₹${_formatNumber(absolute)}';
  }

  static String _formatNumber(
      double value, {
        bool compact = false,
      }) {
    if (!value.isFinite) return '—';

    if (compact) {
      if (value >= 10000000) {
        return '${(value / 10000000).toStringAsFixed(2)} Cr';
      }

      if (value >= 100000) {
        return '${(value / 100000).toStringAsFixed(2)} L';
      }

      if (value >= 1000) {
        return '${(value / 1000).toStringAsFixed(2)} K';
      }
    }

    return value.toStringAsFixed(2);
  }
}

/// Typed exception used by the market-data screens.
class MarketDataException implements Exception {
  final String message;
  final int? statusCode;

  const MarketDataException(
      this.message, {
        this.statusCode,
      });

  @override
  String toString() {
    if (statusCode == null) {
      return message;
    }

    return '$message (HTTP $statusCode)';
  }
}